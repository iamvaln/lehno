import React from "react";

export function TextField({
  label, hint, multiline = false, rows = 4, invalid = false,
  platform = "web", id, style, ...rest
}) {
  const auto = React.useId ? React.useId() : "lehno-field";
  const fieldId = id || auto;
  const Tag = multiline ? "textarea" : "input";

  return (
    <div style={{ display: "grid", gap: "6px", fontFamily: "var(--font-body)" }}>
      {label ? (
        <label htmlFor={fieldId} style={{ fontSize: "var(--text-body-xs)", color: "var(--text-secondary)" }}>
          {label}
        </label>
      ) : null}
      <Tag
        id={fieldId}
        rows={multiline ? rows : undefined}
        aria-invalid={invalid || undefined}
        className="lehno-focusable"
        style={{
          boxSizing: "border-box", width: "100%",
          fontFamily: "var(--font-body)", fontSize: platform === "mobile" ? "16px" : "var(--text-body-m)",
          color: "var(--text-body)", background: "var(--surface-card)",
          border: `1px solid ${invalid ? "var(--feedback-error)" : "var(--border-object)"}`,
          borderRadius: "var(--radius-sm)", padding: "14px 15px",
          minHeight: platform === "mobile" ? "var(--touch-min)" : undefined,
          resize: multiline ? "vertical" : undefined,
          lineHeight: multiline ? 1.5 : undefined,
          transition: "border-color var(--transition-state)",
          ...style
        }}
        {...rest}
      />
      {hint ? (
        <div style={{ fontSize: "var(--text-mention-s)", color: invalid ? "var(--feedback-error)" : "var(--text-mention)" }}>
          {hint}
        </div>
      ) : null}
    </div>
  );
}
