import React from "react";
import { Icon } from "../core/Icon.jsx";

const DEFAULT_TABS = [
  { id: "accueil", label: "Accueil", icon: "house" },
  { id: "dates",   label: "Dates",   icon: "calendar" },
  { id: "proches", label: "Proches", icon: "heart" },
  { id: "moi",     label: "Moi",     icon: "user" }
];

export function TabBar({ tabs = DEFAULT_TABS, active = "accueil", onSelect, style, ...rest }) {
  return (
    <nav
      style={{
        display: "grid", gridTemplateColumns: `repeat(${tabs.length}, 1fr)`,
        borderTop: "1px solid var(--border-hairline)", background: "var(--surface-page)",
        fontFamily: "var(--font-body)", ...style
      }}
      {...rest}
    >
      {tabs.map((t) => {
        const on = t.id === active;
        return (
          <button
            key={t.id}
            type="button"
            onClick={onSelect ? () => onSelect(t.id) : undefined}
            aria-current={on ? "page" : undefined}
            className="lehno-focusable"
            style={{
              display: "flex", flexDirection: "column", alignItems: "center", gap: "3px",
              background: "none", border: "none", cursor: "pointer",
              minHeight: "var(--touch-min)", padding: "9px 4px 10px",
              color: on ? "var(--text-accent)" : "var(--text-mention)",
              fontFamily: "var(--font-body)", fontSize: "11px",
              fontWeight: on ? "var(--font-body-semibold)" : "var(--font-body-regular)",
              transition: "color var(--transition-state)"
            }}
          >
            <Icon name={t.icon} size={20} />
            <span>{t.label}</span>
          </button>
        );
      })}
    </nav>
  );
}
