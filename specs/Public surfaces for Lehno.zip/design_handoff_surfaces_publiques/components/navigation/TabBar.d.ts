import * as React from "react";

export interface TabBarTab {
  id: string;
  label: string;
  /** Nom Lucide. */
  icon: string;
}

export interface TabBarProps extends React.HTMLAttributes<HTMLElement> {
  /** Défaut : Accueil · Dates · Proches · Moi — la navigation de l'application. */
  tabs?: TabBarTab[];
  active?: string;
  onSelect?: (id: string) => void;
}

export declare function TabBar(props: TabBarProps): React.ReactElement;
