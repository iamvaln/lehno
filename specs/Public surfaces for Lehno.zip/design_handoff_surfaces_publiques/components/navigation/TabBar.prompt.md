La barre d'onglets de l'application : **Accueil · Dates · Proches · Moi**. Quatre onglets, pas davantage.

```jsx
<TabBar active="dates" onSelect={setTab} />
```

L'onglet actif prend le violet de texte ; les autres le gris de mention. C'est le seul filet horizontal permanent de l'application — il sépare deux zones qui n'ont rien à voir.
