Le décompte avant une échéance, composé en Fraunces et violet appuyé.

```jsx
<Countdown days={3} size="l" />
<Countdown days={0} />          {/* pilule abricot « aujourd'hui » */}
<Countdown days={3} locale="en" />
```

Un traitement typographique, **pas un élément de signature** : `J−3` n'a pas d'équivalent anglais, et la notation sera éprouvée par un test utilisateur. Le jour même passe à l'abricot — c'est le seul moment heureux du composant.
