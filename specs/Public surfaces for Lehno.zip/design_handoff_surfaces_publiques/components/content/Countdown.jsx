import React from "react";

const SIZES = { s: 20, m: 34, l: 76 };

export function Countdown({ days, locale = "fr", size = "m", today, style, ...rest }) {
  const isToday = today != null ? today : days === 0;
  const label = isToday
    ? (locale === "fr" ? "aujourd'hui" : "today")
    : locale === "fr" ? `J\u2212${days}` : `${days} day${days === 1 ? "" : "s"}`;
  const px = SIZES[size] || SIZES.m;

  if (isToday) {
    return (
      <span
        style={{
          display: "inline-flex", alignItems: "center", fontFamily: "var(--font-body)",
          fontSize: Math.max(12, Math.round(px * 0.36)), fontWeight: "var(--font-body-semibold)",
          background: "var(--celebrate)", color: "var(--on-celebrate)",
          padding: "5px 11px", borderRadius: "var(--radius-pill)", ...style
        }}
        {...rest}
      >
        {label}
      </span>
    );
  }

  return (
    <span
      style={{
        fontFamily: "var(--font-display)", fontVariationSettings: "var(--font-display-settings)",
        fontWeight: "var(--font-display-regular)", fontSize: px, lineHeight: 0.95,
        letterSpacing: "var(--tracking-display)", color: "var(--text-accent)",
        whiteSpace: "nowrap", ...style
      }}
      {...rest}
    >
      {label}
    </span>
  );
}
