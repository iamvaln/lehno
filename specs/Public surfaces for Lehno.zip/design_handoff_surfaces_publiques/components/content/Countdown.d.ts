import * as React from "react";

export interface CountdownProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Jours restants. 0 bascule sur la pilule « aujourd'hui ». */
  days: number;
  /** fr rend « J−3 » ; en rend « 3 days ». La notation reste ouverte — voir readme. */
  locale?: "fr" | "en";
  /** s 20px (ligne de liste) · m 34px (carte) · l 76px (vue d'échéance). */
  size?: "s" | "m" | "l";
  /** Force l'état du jour même. */
  today?: boolean;
}

export declare function Countdown(props: CountdownProps): React.ReactElement;
