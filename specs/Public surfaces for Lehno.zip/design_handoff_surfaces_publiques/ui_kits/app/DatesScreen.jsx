import React from "react";
import { Countdown } from "../../components/content/Countdown.jsx";

const MOIS = [
  { titre: "Août", items: [
    { j: 0, nom: "Awa Diop", quoi: "Anniversaire · 36 ans", date: "22 août" },
    { j: 3, nom: "Valery Bah", quoi: "Anniversaire · 36 ans", date: "24 août" },
    { j: 9, nom: "Mathias & Rose", quoi: "Mariage · 5 ans", date: "30 août" }
  ]},
  { titre: "Septembre", items: [
    { j: 12, nom: "Maman", quoi: "Départ en retraite", date: "2 sept." },
    { j: 24, nom: "Nour & moi", quoi: "Six mois", date: "14 sept." }
  ]}
];

export function DatesScreen({ onOpen }) {
  return (
    <div style={{ padding: "0 16px 18px" }}>
      <h1 className="lehno-display" style={{ fontSize: 27, letterSpacing: "-.025em", margin: "6px 0 18px", fontWeight: 500 }}>
        Vos dates
      </h1>
      {MOIS.map((m) => (
        <section key={m.titre} style={{ marginBottom: 18 }}>
          <div className="lehno-kicker" style={{ marginBottom: 8 }}>{m.titre}</div>
          <div style={{ border: "1px solid var(--border-object)", borderRadius: "var(--radius-lg)", overflow: "hidden" }}>
            {m.items.map((e, i) => (
              <button key={e.nom} type="button" onClick={() => onOpen("proche")} className="lehno-focusable"
                style={{
                  all: "unset", boxSizing: "border-box", cursor: "pointer", width: "100%",
                  display: "flex", alignItems: "center", gap: 12, padding: "13px 14px",
                  minHeight: "var(--touch-min)",
                  borderTop: i ? "1px solid var(--border-hairline)" : "none"
                }}>
                <span className="lehno-display" style={{
                  fontSize: 14, color: "var(--text-accent)", minWidth: 58, fontWeight: 500
                }}>{e.date}</span>
                <span style={{ flex: 1, minWidth: 0 }}>
                  <span className="lehno-display" style={{ fontSize: 16, display: "block" }}>{e.nom}</span>
                  <span style={{ fontSize: 12.5, color: "var(--text-secondary)" }}>{e.quoi}</span>
                </span>
                <Countdown days={e.j} size="s" />
              </button>
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}
