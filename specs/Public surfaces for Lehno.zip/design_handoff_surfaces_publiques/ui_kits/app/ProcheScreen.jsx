import React from "react";
import { Avatar } from "../../components/core/Avatar.jsx";
import { Tag } from "../../components/core/Tag.jsx";
import { Card } from "../../components/core/Card.jsx";
import { SectionLabel } from "../../components/core/SectionLabel.jsx";
import { Quote } from "../../components/content/Quote.jsx";
import { Provenance } from "../../components/content/Provenance.jsx";
import { Countdown } from "../../components/content/Countdown.jsx";
import { Button } from "../../components/core/Button.jsx";

export function ProcheScreen({ onOpen }) {
  return (
    <div style={{ padding: "0 16px 18px" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 4 }}>
        <Avatar name="Valery Bah" size={54} />
        <div style={{ flex: 1 }}>
          <div className="lehno-display" style={{ fontSize: 22 }}>Valery Bah</div>
          <div style={{ fontSize: 13, color: "var(--text-secondary)" }}>Anniversaire · 24 août · registre amical</div>
        </div>
        <Countdown days={3} size="m" />
      </div>

      <div style={{ margin: "18px 0" }}>
        <SectionLabel>Intérêts / goûts</SectionLabel>
        <div style={{ display: "flex", gap: 7, flexWrap: "wrap", marginTop: 8 }}>
          <Tag>vinyles</Tag><Tag>rando</Tag><Tag>café de spécialité</Tag>
        </div>
      </div>

      <Card padding={15} radius="lg" style={{ marginBottom: 10 }}>
        <SectionLabel>Idées cadeaux</SectionLabel>
        <Quote size={15} style={{ marginTop: 6 }}>
          Il a parlé d'un moulin à café manuel, le sien rend l'âme.
        </Quote>
        <Provenance origin="noté" date="en mars" />
      </Card>

      <Card padding={15} radius="lg" style={{ marginBottom: 18 }}>
        <SectionLabel>Dislikes / no-go</SectionLabel>
        <Quote size={15} style={{ marginTop: 6 }}>Je ne bois pas d'alcool.</Quote>
        <Provenance origin="dit par lui" date="en janvier" />
      </Card>

      <div style={{ display: "grid", gap: 10 }}>
        <Button platform="mobile" full onClick={() => onOpen("preparation")}>Préparer le 24 août</Button>
        <Button platform="mobile" full variant="outline" icon="plus">Ajouter une note</Button>
      </div>
    </div>
  );
}
