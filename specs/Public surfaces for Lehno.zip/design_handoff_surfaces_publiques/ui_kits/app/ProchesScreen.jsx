import React from "react";
import { Avatar } from "../../components/core/Avatar.jsx";
import { Icon } from "../../components/core/Icon.jsx";

const GENS = [
  { nom: "Awa Diop", note: "3 notes · anniversaire aujourd'hui" },
  { nom: "Valery Bah", note: "9 notes · anniversaire le 24 août" },
  { nom: "Mathias & Rose", note: "2 notes · mariage le 30 août" },
  { nom: "Maman", note: "14 notes · retraite le 2 septembre" },
  { nom: "Nour", note: "6 notes · six mois le 14 septembre" }
];

export function ProchesScreen({ onOpen }) {
  return (
    <div style={{ padding: "0 16px 18px" }}>
      <h1 className="lehno-display" style={{ fontSize: 27, letterSpacing: "-.025em", margin: "6px 0 18px", fontWeight: 500 }}>
        Vos proches
      </h1>
      <div style={{ display: "grid" }}>
        {GENS.map((p, i) => (
          <button key={p.nom} type="button" onClick={() => onOpen("proche")} className="lehno-focusable"
            style={{
              all: "unset", boxSizing: "border-box", cursor: "pointer",
              display: "flex", alignItems: "center", gap: 12, padding: "11px 0",
              minHeight: "var(--touch-min)",
              borderTop: i ? "1px solid var(--border-hairline)" : "none"
            }}>
            <Avatar name={p.nom} size={40} />
            <span style={{ flex: 1, minWidth: 0 }}>
              <span className="lehno-display" style={{ fontSize: 16, display: "block" }}>{p.nom}</span>
              <span style={{ fontSize: 12.5, color: "var(--text-secondary)" }}>{p.note}</span>
            </span>
            <Icon name="chevron-right" size={15} color="var(--text-mention)" />
          </button>
        ))}
      </div>
    </div>
  );
}
