import React from "react";
import { BrandMark } from "../../components/brand/BrandMark.jsx";
import { Wordmark } from "../../components/brand/Wordmark.jsx";
import { Icon } from "../../components/core/Icon.jsx";

export function AppHeader({ dark, notifications = 0, onBack, title, base = "../../" }) {
  return (
    <header style={{
      display: "flex", alignItems: "center", gap: 10,
      padding: "6px 16px 10px", flex: "none"
    }}>
      {onBack ? (
        <>
          <button type="button" onClick={onBack} className="lehno-focusable" aria-label="Retour"
            style={{ background: "none", border: "none", padding: "6px 6px 6px 0", cursor: "pointer", color: "var(--text-body)" }}>
            <Icon name="chevron-left" size={22} />
          </button>
          <div className="lehno-display" style={{ fontSize: 17 }}>{title}</div>
        </>
      ) : (
        <>
          <BrandMark base={base} size={26} />
          <Wordmark base={base} variant={dark ? "blanc" : "couleur"} height={18} />
        </>
      )}
      <div style={{ marginLeft: "auto", position: "relative" }}>
        <Icon name="bell" size={20} color="var(--text-secondary)" />
        {notifications > 0 ? (
          <span style={{
            position: "absolute", top: -5, right: -6, minWidth: 16, height: 16, padding: "0 4px",
            boxSizing: "border-box", borderRadius: 999, background: "var(--action)",
            color: "var(--text-on-accent)", fontFamily: "var(--font-body)", fontSize: 10,
            fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center"
          }}>{notifications}</span>
        ) : null}
      </div>
    </header>
  );
}
