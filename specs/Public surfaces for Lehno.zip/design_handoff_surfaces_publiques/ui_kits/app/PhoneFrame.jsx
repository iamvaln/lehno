import React from "react";

/** Châssis d'appareil — barre d'état et indicateur d'accueil.
 *  Décor de présentation : rien ici n'appartient au produit. */
export function PhoneFrame({ children, dark = false, time = "9:41" }) {
  return (
    <div style={{
      width: 360, height: 740, flex: "none", position: "relative",
      background: "#0B0A10", borderRadius: 46, padding: 9, boxSizing: "border-box",
      boxShadow: "var(--shadow-device)"
    }}>
      <div style={{
        position: "relative", width: "100%", height: "100%", overflow: "hidden",
        borderRadius: 38, background: "var(--surface-page)",
        display: "flex", flexDirection: "column"
      }}>
        <div style={{
          position: "absolute", top: 0, left: 0, right: 0, height: 44, zIndex: 3,
          display: "flex", alignItems: "center", justifyContent: "space-between",
          padding: "0 26px", pointerEvents: "none",
          fontFamily: "var(--font-body)", fontSize: 13, fontWeight: 600,
          color: "var(--text-body)"
        }}>
          <span>{time}</span>
          <span style={{ display: "flex", gap: 5, alignItems: "center", opacity: .85 }}>
            <span style={{ width: 16, height: 9, border: "1.4px solid currentColor", borderRadius: 2 }} />
          </span>
        </div>
        <div style={{
          position: "absolute", top: 9, left: "50%", transform: "translateX(-50%)",
          width: 104, height: 26, background: "#0B0A10", borderRadius: 14, zIndex: 4
        }} />
        <div style={{ flex: 1, minHeight: 0, display: "flex", flexDirection: "column", paddingTop: 44 }}>
          {children}
        </div>
        <div style={{
          position: "absolute", bottom: 6, left: "50%", transform: "translateX(-50%)",
          width: 116, height: 4, borderRadius: 3, background: "var(--text-body)", opacity: .35, zIndex: 4
        }} />
      </div>
    </div>
  );
}
