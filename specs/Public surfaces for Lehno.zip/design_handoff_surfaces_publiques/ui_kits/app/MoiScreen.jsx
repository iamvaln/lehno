import React from "react";
import { Card } from "../../components/core/Card.jsx";
import { SectionLabel } from "../../components/core/SectionLabel.jsx";
import { Button } from "../../components/core/Button.jsx";
import { Banner } from "../../components/feedback/Banner.jsx";
import { Avatar } from "../../components/core/Avatar.jsx";
import { Icon } from "../../components/core/Icon.jsx";

export function MoiScreen({ base = "../../" }) {
  return (
    <div style={{ padding: "0 16px 18px" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 20 }}>
        <Avatar name="Valentine" src={base + "assets/valentine.png"} size={54} />
        <div>
          <div className="lehno-display" style={{ fontSize: 22 }}>Valentine</div>
          <div style={{ fontSize: 13, color: "var(--text-secondary)" }}>valentine@exemple.fr</div>
        </div>
      </div>

      <Banner intent="warning" style={{ margin: "0 -16px 16px" }}>Il vous reste 4 crédits.</Banner>

      <Card padding={15} radius="lg" style={{ marginBottom: 12 }}>
        <SectionLabel>Vos crédits</SectionLabel>
        <div className="lehno-display" style={{ fontSize: 34, fontWeight: 400, marginTop: 6 }}>
          4 <span style={{ fontSize: 15, color: "var(--text-secondary)" }}>crédits</span>
        </div>
        <div style={{ fontSize: 13, color: "var(--text-secondary)", marginTop: 4 }}>
          100 F le crédit. Un crédit par contenu créé pour vous.
        </div>
        <Button platform="mobile" full style={{ marginTop: 12 }}>Recharger</Button>
      </Card>

      <Card padding={15} radius="lg" style={{ marginBottom: 12 }}>
        <SectionLabel>Mon Mur</SectionLabel>
        <div style={{ fontSize: 14, marginTop: 6 }}>lehno.app/valentine</div>
        <div style={{ fontSize: 12.5, color: "var(--text-secondary)", marginTop: 4 }}>
          Visible par toute personne ayant le lien.
        </div>
        <Button platform="mobile" full variant="outline" icon="share-2" style={{ marginTop: 12 }}>Partager mon Mur</Button>
      </Card>

      <div style={{ display: "grid" }}>
        {["Rappels et notifications", "Langue — Français", "Confidentialité", "Se déconnecter"].map((t, i) => (
          <button key={t} type="button" className="lehno-focusable" style={{
            all: "unset", boxSizing: "border-box", cursor: "pointer",
            display: "flex", alignItems: "center", gap: 10, padding: "13px 0",
            minHeight: "var(--touch-min)", fontSize: 14.5,
            borderTop: i ? "1px solid var(--border-hairline)" : "none"
          }}>
            <span style={{ flex: 1 }}>{t}</span>
            <Icon name="chevron-right" size={15} color="var(--text-mention)" />
          </button>
        ))}
      </div>
    </div>
  );
}
