import React from "react";
import { Card } from "../../components/core/Card.jsx";
import { Countdown } from "../../components/content/Countdown.jsx";
import { Quote } from "../../components/content/Quote.jsx";
import { Provenance } from "../../components/content/Provenance.jsx";
import { Button } from "../../components/core/Button.jsx";
import { Icon } from "../../components/core/Icon.jsx";

export function AccueilScreen({ onOpen }) {
  return (
    <div style={{ padding: "0 16px 18px" }}>
      <h1 className="lehno-display" style={{
        fontSize: 27, letterSpacing: "-.025em", margin: "6px 0 2px", fontWeight: 500
      }}>
        Bonjour, Valentine
      </h1>
      <p style={{ margin: "0 0 18px", fontSize: 14, color: "var(--text-secondary)" }}>
        Deux dates approchent cette semaine.
      </p>

      <div className="lehno-kicker" style={{ marginBottom: 10 }}>Ce qui approche</div>

      <Card surface="panel" padding={15} radius="lg" style={{ marginBottom: 10 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10 }}>
          <div>
            <div className="lehno-display" style={{ fontSize: 18 }}>Awa Diop</div>
            <div style={{ fontSize: 13, color: "var(--text-secondary)", marginTop: 1 }}>Anniversaire · 36 ans</div>
          </div>
          <Countdown days={0} />
        </div>
        <Quote size={14} style={{ marginTop: 10 }}>
          Elle a parlé d'un cours de céramique près de chez elle.
        </Quote>
        <Provenance origin="noté" date="en mars" />
        <Button platform="mobile" full style={{ marginTop: 14 }} onClick={() => onOpen("preparation")}>
          Préparer
        </Button>
      </Card>

      {[
        { nom: "Valery Bah", quoi: "Anniversaire · 24 août", j: 3 },
        { nom: "Mathias & Rose", quoi: "Mariage · 30 août", j: 9 }
      ].map((e) => (
        <Card key={e.nom} padding={15} radius="lg" style={{ marginBottom: 10 }}>
          <button type="button" onClick={() => onOpen("proche")} className="lehno-focusable"
            style={{
              all: "unset", cursor: "pointer", width: "100%", display: "flex",
              justifyContent: "space-between", alignItems: "center", gap: 10
            }}>
            <span>
              <span className="lehno-display" style={{ fontSize: 18, display: "block" }}>{e.nom}</span>
              <span style={{ fontSize: 13, color: "var(--text-secondary)" }}>{e.quoi}</span>
            </span>
            <Countdown days={e.j} size="m" />
          </button>
        </Card>
      ))}

      <button type="button" className="lehno-focusable" style={{
        all: "unset", cursor: "pointer", marginTop: 8, display: "flex", alignItems: "center", gap: 8,
        color: "var(--text-accent)", fontFamily: "var(--font-body)", fontSize: 15, fontWeight: 600
      }}>
        <Icon name="plus" size={18} /> Laisser une note
      </button>
    </div>
  );
}
