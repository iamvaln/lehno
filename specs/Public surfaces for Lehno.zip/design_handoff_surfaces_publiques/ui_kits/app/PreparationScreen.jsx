import React from "react";
import { Card } from "../../components/core/Card.jsx";
import { SectionLabel } from "../../components/core/SectionLabel.jsx";
import { Quote } from "../../components/content/Quote.jsx";
import { Provenance } from "../../components/content/Provenance.jsx";
import { Button } from "../../components/core/Button.jsx";
import { Banner } from "../../components/feedback/Banner.jsx";

export function PreparationScreen() {
  const [sent, setSent] = React.useState(false);
  return (
    <div style={{ padding: "0 16px 18px" }}>
      {sent ? <Banner intent="success" style={{ margin: "0 -16px 14px" }}>Message marqué comme envoyé à Valery.</Banner> : null}

      <div className="lehno-display" style={{ fontSize: 22, marginBottom: 2 }}>Pour Valery</div>
      <div style={{ fontSize: 13, color: "var(--text-secondary)", marginBottom: 18 }}>Anniversaire · 24 août</div>

      <Card surface="panel" padding={16} radius="lg" style={{ marginBottom: 14 }}>
        <SectionLabel>Brouillon</SectionLabel>
        <Quote size={17} style={{ marginTop: 8 }}>
          Valery, 36 ans et toujours cette manie de refaire le monde à minuit. Merci pour l'été dernier — je te dois au moins un café correct. Bon anniversaire, mon vieux.
        </Quote>
        <Provenance origin="écrit à partir de 9 notes sur Valery" />
        <div style={{ display: "flex", gap: 8, marginTop: 14, flexWrap: "wrap" }}>
          <Button platform="mobile" onClick={() => setSent(true)}>Modifier et envoyer</Button>
          <Button platform="mobile" variant="outline" icon="refresh-cw">Régénérer</Button>
        </div>
      </Card>

      <SectionLabel>Idées de célébration</SectionLabel>
      <div style={{ display: "grid", gap: 0, marginTop: 8 }}>
        {[
          "Une lettre sur ce que son amitié a changé cette année",
          "Un après-midi au marché aux vinyles, puis un café",
          "Le moulin à café manuel dont il a parlé en mars"
        ].map((t, i) => (
          <div key={t} style={{
            display: "flex", gap: 10, alignItems: "baseline", padding: "10px 0",
            borderTop: i ? "1px solid var(--border-hairline)" : "none",
            fontSize: 14.5, color: "var(--text-secondary)"
          }}>
            <span className="lehno-display" style={{ color: "var(--text-accent)" }}>·</span>
            <span>{t}</span>
          </div>
        ))}
      </div>
      <div style={{ fontSize: 11.5, color: "var(--text-mention)", marginTop: 12 }}>
        Un crédit dépensé · il vous en reste 4
      </div>
    </div>
  );
}
