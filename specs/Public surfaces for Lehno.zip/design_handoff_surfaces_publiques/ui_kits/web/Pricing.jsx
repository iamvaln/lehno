import React from "react";

export function Pricing({ t }) {
  return (
    <section id="prix" style={{ background: "var(--surface-page)" }}>
      <div style={{
        maxWidth: "var(--page-max)", margin: "0 auto",
        padding: "clamp(44px,6vw,76px) var(--page-gutter) clamp(48px,7vw,84px)"
      }}>
        <div className="lehno-kicker">{t.prixKicker}</div>
        <div style={{
          display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(280px,1fr))",
          gap: "clamp(24px,4vw,48px)", marginTop: 28
        }}>
          <div style={{ borderTop: "2px solid var(--action)", paddingTop: 18 }}>
            <div className="lehno-display" style={{
              fontSize: "clamp(38px,5vw,52px)", fontWeight: 400, lineHeight: 1,
              letterSpacing: "-.03em", color: "var(--text-accent)"
            }}>{t.prixGratuitChiffre}</div>
            <h3 className="lehno-display" style={{ fontSize: 21, margin: "14px 0 8px" }}>{t.prixGratuitTitre}</h3>
            <p style={{ margin: 0, color: "var(--text-secondary)", maxWidth: "40ch" }}>{t.prixGratuit}</p>
          </div>
          <div style={{ borderTop: "2px solid var(--border-object)", paddingTop: 18 }}>
            <div className="lehno-display" style={{
              fontSize: "clamp(38px,5vw,52px)", fontWeight: 400, lineHeight: 1, letterSpacing: "-.03em"
            }}>
              {t.prixCreditsChiffre}
              <span style={{
                fontSize: ".42em", letterSpacing: 0, color: "var(--text-secondary)", marginLeft: ".5em"
              }}>{t.prixCreditsUnite}</span>
            </div>
            <h3 className="lehno-display" style={{ fontSize: 21, margin: "14px 0 8px" }}>{t.prixCreditsTitre}</h3>
            <p style={{ margin: 0, color: "var(--text-secondary)", maxWidth: "40ch" }}>{t.prixCredits}</p>
          </div>
        </div>
      </div>
    </section>
  );
}
