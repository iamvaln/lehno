import React from "react";

export function ClosingBand({ t, lance, base = "../../" }) {
  return (
    <section style={{ background: "var(--surface-band)", color: "var(--on-band)" }}>
      <div style={{
        maxWidth: "var(--page-max)", margin: "0 auto",
        padding: "clamp(52px,8vw,88px) var(--page-gutter)",
        display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(300px,1fr))",
        gap: "clamp(28px,4vw,56px)", alignItems: "center"
      }}>
        <h2 className="lehno-display" style={{
          fontSize: "clamp(32px,5vw,52px)", lineHeight: 1.06,
          letterSpacing: "-.032em", margin: 0, maxWidth: "20ch", textWrap: "balance"
        }}>{t.finTitre}</h2>
        <div style={{ display: "flex", gap: 14, alignItems: "center", flexWrap: "wrap" }}>
          {lance ? (
            <>
              <a href="#"><img src={base + "assets/badges/appstore-" + (t.langue === "fr" ? "fr" : "en") + "-blanc.svg"}
                alt={t.altApple} style={{ display: "block", height: 45, width: "auto" }} /></a>
              <a href="#"><img src={base + "assets/badges/googleplay-" + (t.langue === "fr" ? "fr" : "en") + ".png"}
                alt={t.altGoogle} style={{ display: "block", height: 45, width: "auto" }} /></a>
            </>
          ) : (
            <a href="#commencer" style={{
              background: "var(--celebrate)", color: "#221F2B", padding: "16px 28px",
              borderRadius: "var(--radius-md)", fontWeight: 700, fontSize: 17,
              textDecoration: "none", fontFamily: "var(--font-body)"
            }}>{t.commencer}</a>
          )}
        </div>
      </div>
    </section>
  );
}
