import React from "react";
import { Icon } from "../../components/core/Icon.jsx";
import { ARediger } from "./ARediger.jsx";

/** Gabarit FAQ — les réponses sont écrites.
 *
 *  J'avais d'abord traité cette page comme les pages légales : titres réels, corps en
 *  « à rédiger ». C'était une erreur de catégorie. Le corps d'une condition générale est
 *  une décision de responsabilité ; une réponse de FAQ est de la **copy produit**, et
 *  rien n'empêche de l'écrire. Ne restent en attente que les questions dont la réponse
 *  n'est pas tranchée (expiration des crédits, accès aux contacts) — elles gardent leur
 *  bloc, ce qui les rend visibles comme décisions à prendre.
 *  Accordéon : plusieurs entrées peuvent être ouvertes, rien ne se referme
 *  tout seul. La question reste une cible de 44 px, même au clavier. */
function Entree({ q, reponse, couvre, label, quiRedige }) {
  const [ouvert, setOuvert] = React.useState(false);
  return (
    <div style={{ borderTop: "1px solid var(--border-hairline)" }}>
      <button type="button" onClick={() => setOuvert((v) => !v)}
        aria-expanded={ouvert} className="lehno-focusable"
        style={{
          all: "unset", boxSizing: "border-box", cursor: "pointer", width: "100%",
          display: "flex", alignItems: "center", gap: 14, minHeight: 56, padding: "12px 0",
          fontFamily: "var(--font-body)", fontSize: 17, color: "var(--text-body)"
        }}>
        <span style={{ flex: 1, minWidth: 0, textWrap: "pretty" }}>{q}</span>
        <span style={{
          flex: "none", display: "grid", placeItems: "center",
          transform: ouvert ? "rotate(180deg)" : "none",
          transition: "transform var(--transition-enter)"
        }}>
          <Icon name="chevron-down" size={18} color="var(--text-mention)" />
        </span>
      </button>
      <div style={{
        display: "grid", gridTemplateRows: ouvert ? "1fr" : "0fr",
        transition: "grid-template-rows var(--transition-enter)"
      }}>
        <div style={{ overflow: "hidden" }}>
          <div style={{ paddingBottom: 18 }}>
            {reponse ? (
              <p style={{
                margin: 0, fontSize: 16.5, lineHeight: 1.6, maxWidth: "62ch",
                color: "var(--text-secondary)", textWrap: "pretty"
              }}>{reponse}</p>
            ) : (
              <ARediger couvre={couvre} label={label} qui={quiRedige} />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export function FaqPage({ t }) {
  const p = t.faq;
  return (
    <div style={{
      maxWidth: "var(--page-max)", margin: "0 auto",
      padding: "clamp(40px,5vw,68px) var(--page-gutter) clamp(52px,7vw,92px)"
    }}>
      <header style={{ marginBottom: 38, maxWidth: "62ch" }}>
        <div style={{
          fontSize: 11, fontWeight: 700, letterSpacing: ".14em", textTransform: "uppercase",
          color: "var(--text-mention)", marginBottom: 12
        }}>{p.kicker}</div>
        <h1 style={{
          margin: 0, fontFamily: "var(--font-display)",
          fontVariationSettings: "var(--font-display-settings)",
          fontWeight: 400, fontSize: "clamp(34px,4.4vw,52px)", lineHeight: 1.05,
          letterSpacing: "-.025em", textWrap: "balance"
        }}>{p.titre}</h1>
        <p style={{
          margin: "16px 0 0", fontSize: 17, lineHeight: 1.6,
          color: "var(--text-secondary)", textWrap: "pretty"
        }}>{p.chapeau}</p>
      </header>

      <div style={{ display: "grid", gap: 44, maxWidth: 760 }}>
        {p.groupes.map((g) => (
          <section key={g.titre}>
            <h2 style={{
              margin: "0 0 6px", fontSize: 11, fontWeight: 700,
              letterSpacing: ".14em", textTransform: "uppercase", color: "var(--text-mention)"
            }}>{g.titre}</h2>
            <div style={{ borderBottom: "1px solid var(--border-hairline)" }}>
              {g.items.map((it) => (
                <Entree key={it.q} q={it.q} reponse={it.reponse} couvre={it.couvre}
                  label={t.aRediger} quiRedige={p.quiRedige} />
              ))}
            </div>
          </section>
        ))}
      </div>
    </div>
  );
}
