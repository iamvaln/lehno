import React from "react";

export function HowItWorks({ t }) {
  return (
    <section id="comment" style={{ background: "var(--surface-panel)" }}>
      <div style={{
        maxWidth: "var(--page-max)", margin: "0 auto",
        padding: "var(--section-pad-y) var(--page-gutter)"
      }}>
        <div className="lehno-kicker" style={{ color: "var(--text-accent)" }}>{t.navComment}</div>
        <div style={{
          display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(240px,1fr))",
          gridTemplateRows: "auto auto auto", gap: "clamp(28px,4vw,44px)",
          marginTop: "clamp(32px,4vw,44px)"
        }}>
          {t.etapes.map((e, i) => (
            <div key={i} style={{
              display: "grid", gridTemplateRows: "subgrid", gridRow: "span 3",
              gap: 0, alignContent: "start", minWidth: 0
            }}>
              <div className="lehno-display" style={{
                fontSize: "clamp(44px,6vw,60px)", fontWeight: 400,
                color: "var(--text-accent)", lineHeight: 1
              }}>{"0" + (i + 1)}</div>
              <h3 className="lehno-display" style={{
                fontSize: 25, letterSpacing: "-.02em", margin: "14px 0 10px", textWrap: "balance"
              }}>{e[0]}</h3>
              <p style={{ margin: 0, color: "var(--text-secondary)", maxWidth: "34ch" }}>{e[1]}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
