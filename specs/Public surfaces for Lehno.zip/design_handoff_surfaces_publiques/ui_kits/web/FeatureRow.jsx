import React from "react";

/** Une station de contenu : titre + texte d'un côté, illustration de l'autre.
 *  Les stations alternent blanc / lilas — c'est cette alternance qui rythme
 *  la page, pas des filets. */
export function FeatureRow({ id, titre, texte, panel = false, inverse = false, children, extra }) {
  return (
    <section id={id} style={{ background: panel ? "var(--surface-panel)" : "var(--surface-page)" }}>
      <div style={{
        maxWidth: "var(--page-max)", margin: "0 auto",
        padding: "var(--section-pad-y) var(--page-gutter)"
      }}>
        <div className="feature-grid" style={{
          display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(300px,1fr))",
          gap: "clamp(28px,4vw,56px)", alignItems: "center"
        }}>
          <div style={{ minWidth: 0, order: inverse ? 2 : 1 }}>
            <h2 className="lehno-display" style={{
              fontSize: "clamp(28px,4vw,38px)", letterSpacing: "-.028em",
              lineHeight: 1.12, margin: "0 0 14px", textWrap: "balance"
            }}>{titre}</h2>
            <p style={{
              margin: 0, color: "var(--text-secondary)", fontSize: 18, maxWidth: "42ch"
            }}>{texte}</p>
            {extra}
          </div>
          <div style={{ minWidth: 0, order: inverse ? 1 : 2, display: "flex", justifyContent: "center" }}>
            {children}
          </div>
        </div>
      </div>
    </section>
  );
}
