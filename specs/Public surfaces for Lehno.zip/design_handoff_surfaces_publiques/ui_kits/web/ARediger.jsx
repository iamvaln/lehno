import React from "react";
import { Icon } from "../../components/core/Icon.jsx";

/** Le bloc « à rédiger ».
 *  La structure et les titres des pages légales sont arrêtés ; le corps ne peut
 *  pas l'être — c'est un texte de responsabilité, pas un texte de design. Le bloc
 *  dit ce que la section doit couvrir, et qui l'écrit. Il est fait pour être vu
 *  et retiré, jamais pour passer en production tel quel. */
export function ARediger({ couvre, label = "À rédiger", qui = "PROXIA LABS · à faire relire par un conseil juridique" }) {
  return (
    <div style={{
      border: "1px dashed var(--border-object)", borderRadius: "var(--radius-md)",
      background: "var(--surface-panel)", padding: "14px 16px", margin: "10px 0 4px"
    }}>
      <div style={{
        display: "flex", alignItems: "center", gap: 7, marginBottom: 7,
        fontSize: 10.5, fontWeight: 700, letterSpacing: ".14em", textTransform: "uppercase",
        color: "var(--text-mention)"
      }}>
        <Icon name="pencil-line" size={13} color="var(--text-mention)" />
        {label}
      </div>
      <p style={{
        margin: 0, fontSize: 15, color: "var(--text-secondary)",
        textWrap: "pretty", maxWidth: "62ch"
      }}>{couvre}</p>
      <div style={{
        marginTop: 9, paddingTop: 8, borderTop: "1px solid var(--border-hairline)",
        fontSize: 11.5, color: "var(--text-mention)"
      }}>{qui}</div>
    </div>
  );
}
