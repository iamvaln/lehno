import React from "react";
import { Avatar } from "../../components/core/Avatar.jsx";
import { Banner } from "../../components/feedback/Banner.jsx";

/** Invitation au parrainage — silhouette « carte ».
 *
 *  J'en avais fait une landing courte : héros à deux colonnes, maquette de téléphone,
 *  aplat lilas, chiffre à 82 px, section d'installation titrée, encadré de code — quatre
 *  sections et deux systèmes visuels pour dire une seule chose. C'était de l'argumentaire
 *  de marque là où il n'y a qu'une recommandation entre deux personnes.
 *
 *  Une invitation est **intime** : quelqu'un vous dit que ça vous servira. La page tient
 *  donc en une colonne, sur du blanc, sans aplat ni maquette : qui invite, ce que fait
 *  Lehno, ce qu'il y a à l'ouverture, comment l'installer. Le gain se dit sur une ligne
 *  au lieu de tenir une section — un chiffre en Fraunces, la raison juste après.
 *
 *  **La page ne porte pas la clôture d'acquisition de la coquille** : elle *est* la
 *  page d'acquisition. Répéter « Découvrir Lehno » sous les badges des magasins
 *  reviendrait à proposer deux fois la même chose dans deux tons différents.
 *
 *  `etat` : `valide` · `expire` · `deja`. Sans code valable il n'y a pas de gain à
 *  annoncer : la ligne disparaît, les badges restent. */
export function InvitePage({ t, etat = "valide", base = "../../", langue = "fr" }) {
  const p = t.invitation;
  const valide = etat === "valide";

  return (
    <div style={{ display: "grid", gap: 30, paddingTop: "clamp(8px,2vw,24px)" }}>
      {etat === "expire" ? <Banner intent="warning">{p.avertExpire}</Banner> : null}
      {etat === "deja" ? <Banner intent="info">{p.avertDeja}</Banner> : null}

      {valide ? (
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <Avatar name={p.parrain} size={40} />
          <div style={{ fontSize: 15.5, color: "var(--text-secondary)" }}>
            <strong style={{ color: "var(--text-body)", fontWeight: 600 }}>{p.parrain}</strong>
            {" " + p.parrainMention}
          </div>
        </div>
      ) : null}

      <div>
        <h1 className="lehno-display" style={{
          margin: 0, fontSize: "clamp(29px,3.4vw,40px)", lineHeight: 1.08,
          letterSpacing: "-.03em", maxWidth: "18ch", textWrap: "balance"
        }}>{valide ? p.titre : p.titreSansCode}</h1>
        <p style={{
          margin: "16px 0 0", fontSize: 17, lineHeight: 1.6,
          color: "var(--text-secondary)", maxWidth: "42ch", textWrap: "pretty"
        }}>{p.promesse}</p>
      </div>

      {/* Le gain tient sur une ligne : un chiffre, puis sa raison. */}
      {valide ? (
        <p style={{
          margin: 0, paddingTop: 24, borderTop: "1px solid var(--border-hairline)",
          fontSize: 17, lineHeight: 1.6, maxWidth: "44ch", textWrap: "pretty"
        }}>
          <span className="lehno-display" style={{
            fontSize: 26, letterSpacing: "-.03em", color: "var(--text-accent)"
          }}>{p.gainChiffre}</span>
          {" " + p.gainTexte}
        </p>
      ) : null}

      <div style={{ display: "grid", gap: 14, justifyItems: "start" }}>
        <div style={{ display: "flex", gap: 12, flexWrap: "wrap", alignItems: "center" }}>
          <a href="#" style={{ display: "inline-flex" }}>
            <img src={base + "assets/badges/appstore-" + langue + "-noir.svg"}
              alt={p.altApple} style={{ display: "block", height: 44 }} />
          </a>
          <a href="#" style={{ display: "inline-flex" }}>
            <img src={base + "assets/badges/googleplay-" + langue + ".png"}
              alt={p.altGoogle} style={{ display: "block", height: 44 }} />
          </a>
        </div>
        {valide ? (
          <div style={{ fontSize: 13.5, color: "var(--text-mention)" }}>
            {p.codeLabel + " "}
            <span style={{
              fontWeight: 700, letterSpacing: ".08em", color: "var(--text-accent)"
            }}>{p.code}</span>
          </div>
        ) : null}
      </div>
    </div>
  );
}
