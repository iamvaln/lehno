import React from "react";
import { Button } from "../../components/core/Button.jsx";
import { TextField } from "../../components/forms/TextField.jsx";
import { PhoneFrame } from "../app/PhoneFrame.jsx";
import { AppHeader } from "../app/AppHeader.jsx";
import { AccueilScreen } from "../app/AccueilScreen.jsx";
import { TabBar } from "../../components/navigation/TabBar.jsx";

export function Hero({ t, lance, nuit, base = "../../" }) {
  const [envoye, setEnvoye] = React.useState(false);
  return (
    <section style={{ background: "var(--surface-page)" }}>
      <div className="hero-grid" style={{
        maxWidth: "var(--page-max)", margin: "0 auto",
        padding: "clamp(40px,6vw,72px) var(--page-gutter) clamp(48px,7vw,84px)",
        display: "grid", gridTemplateColumns: "1.1fr .9fr",
        gap: "clamp(28px,4vw,60px)", alignItems: "center"
      }}>
        <div style={{ minWidth: 0 }}>
          <h1 className="lehno-display" style={{
            fontSize: "clamp(40px,6.4vw,72px)", lineHeight: 1.02,
            letterSpacing: "var(--tracking-display)", margin: 0, textWrap: "balance"
          }}>{t.heroTitre}</h1>
          <p style={{
            fontSize: "clamp(17px,2vw,21px)", lineHeight: 1.5, color: "var(--text-secondary)",
            maxWidth: "34ch", margin: "22px 0 0", textWrap: "pretty"
          }}>{t.heroTexte}</p>

          <div style={{ marginTop: 30 }}>
            {lance ? (
              <div style={{ display: "flex", gap: 12, flexWrap: "wrap", alignItems: "center" }}>
                <a href="#"><img src={base + "assets/badges/appstore-" + (t.langue === "fr" ? "fr" : "en") + (nuit ? "-blanc" : "-noir") + ".svg"}
                  alt={t.altApple} style={{ display: "block", height: 45, width: "auto" }} /></a>
                <a href="#"><img src={base + "assets/badges/googleplay-" + (t.langue === "fr" ? "fr" : "en") + ".png"}
                  alt={t.altGoogle} style={{ display: "block", height: 45, width: "auto" }} /></a>
              </div>
            ) : envoye ? (
              <div style={{
                background: "var(--surface-panel)", borderRadius: "var(--radius-md)",
                padding: "18px 20px", maxWidth: 440
              }}>
                <div className="lehno-display" style={{ fontSize: 19, color: "var(--text-accent)" }}>{t.merciTitre}</div>
                <div style={{ fontSize: 14, color: "var(--text-secondary)", marginTop: 4 }}>{t.merciTexte}</div>
              </div>
            ) : (
              <>
                <div style={{ display: "flex", gap: 10, flexWrap: "wrap", maxWidth: 460, alignItems: "flex-start" }}>
                  <div style={{ flex: "1 1 220px" }}>
                    <TextField type="email" placeholder={t.emailPlaceholder} aria-label={t.emailPlaceholder} />
                  </div>
                  <Button onClick={() => setEnvoye(true)} style={{ minHeight: 50 }}>{t.commencer}</Button>
                </div>
                <div style={{ fontSize: 13, color: "var(--text-mention)", marginTop: 12 }}>{t.heroNote}</div>
              </>
            )}
          </div>
        </div>

        <div className="hero-phone" style={{
          background: "var(--surface-panel)", borderRadius: 28,
          padding: "40px 30px 0", display: "flex", justifyContent: "center", overflow: "hidden"
        }}>
          <div style={{ transform: "scale(.86)", transformOrigin: "top center" }}>
            <PhoneFrame>
              <AppHeader dark={nuit} notifications={2} base={base} />
              <div style={{ flex: 1, minHeight: 0, overflow: "hidden" }}>
                <AccueilScreen onOpen={() => {}} />
              </div>
              <div style={{ flex: "none", paddingBottom: 14 }}><TabBar active="accueil" /></div>
            </PhoneFrame>
          </div>
        </div>
      </div>
    </section>
  );
}
