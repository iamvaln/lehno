# UI kit — le site public

Recréation de **lehno.app** : la landing bilingue et le Mur. `index.html` monte les
deux, avec les bascules langue, thème et état de lancement.

| Fichier | Rôle |
|---|---|
| `SiteHeader.jsx` | En-tête collant — navigation, langue, thème, action. Sous 880 px la navigation passe en accordéon ; langue, thème et bouton restent en place. |
| `Hero.jsx` | Héros — titre, chapeau, capture d'e-mail *ou* badges de magasins, et l'accueil de l'application dans un téléphone. |
| `HowItWorks.jsx` | Les trois temps, en `grid-template-rows: subgrid` pour que numéros, titres et paragraphes se calent. |
| `FeatureRow.jsx` | Une station de contenu, alternant blanc et lilas. |
| `Pricing.jsx` | Gratuit / crédits — le prix posé en chiffre, comme le décompte. |
| `ClosingBand.jsx` | L'aplat de clôture : encre en clair, violet profond en sombre. |
| `SiteFooter.jsx` | Marque, signature, trois liens. |
| `WallPage.jsx` | Le Mur — la page publique d'un utilisateur. |

## Les pages secondaires

`pages.html` monte les six pages qui ne sont pas la landing, avec les mêmes bascules
langue et thème. Trois gabarits, parce qu'un texte légal, un formulaire et une FAQ ne
se ressemblent pas :

| Fichier | Rôle |
|---|---|
| `LegalPage.jsx` | Gabarit légal — sommaire collant qui suit la lecture, corps à 62ch, un titre par obligation. Sert aux Conditions, à la Confidentialité et à la Suppression de compte (qui ajoute une procédure numérotée). |
| `FaqPage.jsx` | Accordéon groupé — plusieurs entrées ouvrables, rien ne se referme tout seul. |
| `ContactPage.jsx` | Formulaire (validation à la saisie) et comptes publics. Deux canaux seulement : une liste de moyens de contact est une liste de promesses. |
| `NotFoundPage.jsx` | 404 — ce qui s'est passé, et la suite. Pas d'illustration, pas d'« Oups ». |
| `ARediger.jsx` | Le bloc « à rédiger » — voir ci-dessous. |

**Le corps des pages légales n'est pas écrit, et c'est volontaire.** Les titres, l'ordre
et le périmètre de chaque section sont arrêtés ; le texte est une décision de
responsabilité, pas de design. Chaque section porte donc un bloc `ARediger` qui dit ce
qu'elle doit couvrir et qui l'écrit. Le bloc est fait pour être vu et retiré — jamais
pour passer en production.

**À confirmer avant publication** : l'entité (PROXIA LABS) et son pays d'établissement,
l'autorité de protection des données compétente, le sort des crédits non dépensés à la
fermeture d'un compte, les comptes de réseaux sociaux, et le délai de réponse annoncé
sur la page Contact (« deux jours ouvrés » est un engagement, pas une formule).

## Les surfaces de lien

`surfaces.html` monte les quatre pages qu'on atteint par un lien. Elles portent **le même
en-tête et le même pied que la landing** : ce sont des pages du même site, et un visiteur
qui découvre Lehno par le Mur d'une amie doit pouvoir aller voir ce qu'est Lehno. La
coquille (`PublicShell.jsx`) tient ce cadre, plus l'aplat de clôture — celui de la
landing, mêmes couleurs, même bouton abricot — qui porte le CTA d'acquisition que la spec
veut sur toutes les pages publiques.

**Ce qui change d'une page à l'autre, c'est la silhouette du contenu, pas le cadre.**
Quatre objectifs, quatre silhouettes :

| Page | Objectif | Silhouette |
|---|---|---|
| `CollectPage.jsx` | Qu'un proche réponde vite et bien, sans se sentir interrogé | **Conversation, puis formulaire** — on salue la personne, on dit de qui vient l'invitation, puis les champs resserrés (voir « Qui parle, sur la collecte ») |
| `WishDropPage.jsx` | Écrire un mot en trente secondes, debout | **Billet** — le champ de message *est* la page ; le décompte se réduit à une ligne de contexte |
| `InvitePage.jsx` | Convaincre d'installer, sur recommandation | **Landing courte** — le vocabulaire de la landing (héros, station lilas, badges) resserré à un seul argument |
| `StatePage.jsx` | Ne pas laisser le visiteur dans le vide | **Avis court** — le titre porte l'information, une ligne l'explique, le pied offre la sortie. Pas d'icône décorative, pas d'« Oups » |

La barre sombre en haut de `surfaces.html` est une **barre d'aperçu**, pas un élément des
pages : elle sert à passer d'une surface à l'autre, et affiche la silhouette de la page
courante. La navigation du produit est dans l'en-tête, comme partout.

## Pas de page de portrait partagé

La spéc des surfaces publiques en prévoit une (§3.6). **Elle n'existe pas, et c'est une
décision, pas un oubli.**

Le portrait est une **image** : le propriétaire le compose dans l'application, l'exporte
et l'envoie — sur WhatsApp, dans une conversation. Le fichier voyage, avec son pied de
marque dedans ; il n'a pas besoin d'une page web pour être vu. Une page publique
n'ajouterait qu'un intermédiaire à un partage qui marche déjà, et forcerait le portrait à
se transformer en mise en page HTML, ce qu'il n'est pas.

L'acquisition, elle, reste servie : le pied de marque fait partie de l'image.

Ce qui appartient donc au chantier de l'application mobile : la composition du portrait
(3.7), son aperçu et son export (3.22). L'illustration d'exemple est conservée dans
`assets/portraits/`.

## Qui parle, sur la collecte

Deux ouvertures possibles, et il faut savoir laquelle on montre.

**Par défaut, c'est le produit qui parle** : une phrase en romain, au vouvoiement,
composée du prénom du propriétaire — « Valentine prépare votre anniversaire et voudrait
ne pas se tromper. »

**La prop `motProprietaire` affiche à la place le mot du propriétaire lui-même** — et là
seulement, l'italique et le tutoiement sont légitimes, avec sa signature dessous, parce
que ce sont ses mots.

`CollectionLink` **n'a pas de champ pour ce mot** : l'afficher demande d'ajouter
`invitation_message` (text, nullable) au dictionnaire. C'est une bonne chose à ajouter —
la page est nettement plus chaleureuse quand la demande vient d'elle. En attendant, aucune
page ne doit composer une fausse citation : mettre en italique une phrase que le
propriétaire n'a pas écrite lui fait dire ce qu'il n'a pas dit.

## Un souhait n'est pas un titre

Le modèle porte six choses utiles à qui veut offrir : l'intitulé, des **précisions
libres** (taille, couleur, référence, où le trouver), un **prix indicatif**, un **lien**,
une **photo** facultative, et un **état**. `WishCard.jsx` les montre dans cet ordre —
celui dans lequel on décide : *qu'est-ce que c'est, est-ce que je peux, où je l'achète.*
Le formulaire de collecte recueille les mêmes champs, derrière un « Préciser » qui garde
la première saisie courte — **photo comprise** : « le bleu indigo, pas le turquoise » se
règle mieux en une image qu'en une phrase, et sur téléphone l'appareil photo s'ouvre
directement.

**Deux champs manquent au dictionnaire pour que tout ceci existe** :
`SubmittedWish.image_url` (la photo prise par le répondant ; `WishlistItem` l'a déjà) et
`SubmittedWish.details` (les précisions libres ; `WishlistItem` l'a déjà aussi). Les deux
sont les mêmes champs que côté propriétaire — c'est le canal d'entrée qui est plus pauvre
que la destination, ce qui n'a pas de raison d'être. La photo entraîne les règles du §9.6
de la spéc. technique : type réel vérifié d'après le contenu, poids et dimensions bornés,
image recomposée, métadonnées retirées, servie depuis un domaine distinct.

Trois règles sur la liste du Mur :
- **Elle s'ouvre d'un geste.** Un visiteur venu dire bonjour n'a pas à tomber sur une
  liste de cadeaux.
- **Un souhait réservé se dit réservé, jamais par qui.** Le visiteur qui revient avec son
  jeton retrouve les siens, et ceux-là seulement. L'anonymat se dit **une fois**, en pied
  de liste : répété sur chaque carte, un rappel devient du bruit.
- **Le lien est affiché en clair** (le domaine) et s'ouvre en isolation : on voit où l'on
  va avant de cliquer.

Deux chemins de réservation, comme au dictionnaire : un utilisateur connecté réserve en un
geste ; un visiteur laisse une adresse, choisit ou non de se faire connaître, et confirme
par un code.

## Trois choses retirées, volontairement

**Le livre d'or.** Le Mur montrait un vœu reçu, avec son auteur. La spec dit le contraire :
les vœux arrivent au propriétaire et ne s'affichent jamais sur la page. Le bloc est devenu
une invitation à en laisser un.

**La mention « créé avec Lehno »** en pied de Mur. Le Mur est déjà servi à l'adresse de
Lehno : la marque est là, seule l'invitation compte.

**Le champ « pseudo Lehno »** du formulaire de collecte. La spec le prévoit en facultatif,
mais c'est un champ de plus pour un rattachement auto-déclaré et invérifiable, que la
plupart des répondants ne peuvent pas remplir. Il reviendra par le lien profond : ouvrir
le lien depuis l'application identifie le répondant sans rien lui demander.

## Deux choses à savoir

**Le rythme est fait d'aplats, pas de filets.** Blanc (héros) → lilas → blanc → lilas →
blanc → lilas → aplat de clôture. En sombre, l'aplat de clôture quitte l'encre pour le
violet profond : l'encre ne tranche pas sur l'encre.

**Le Mur change de personne.** Sur la landing, le produit vouvoie l'utilisateur. Sur le
Mur, c'est son propriétaire qui parle à ses proches — « je », tutoiement. C'est la seule
surface où la marque ne parle pas en son nom.

## Le dictionnaire

La copy FR / EN vit dans un `<script type="application/json">` de `index.html` et
descend par la prop `t`. Les deux langues sont écrites, pas traduites mot à mot.

## Ce qui n'est pas représenté

Les prix (100 F, 5 crédits) sont ici en dur ; sur le site réel ils sont lus depuis
`/public/config`. La page À propos n'existe pas.
