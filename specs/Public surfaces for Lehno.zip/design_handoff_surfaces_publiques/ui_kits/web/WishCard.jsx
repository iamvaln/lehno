import React from "react";
import { Tag } from "../../components/core/Tag.jsx";
import { Button } from "../../components/core/Button.jsx";
import { Icon } from "../../components/core/Icon.jsx";
import { TextField } from "../../components/forms/TextField.jsx";

/** Un souhait — la brique de la liste, sur le Mur.
 *
 *  **Un souhait n'est pas un titre.** Le modèle en porte six choses utiles à qui
 *  veut offrir : l'intitulé, des précisions libres (taille, couleur, référence, où
 *  le trouver), un prix indicatif, un lien, une photo facultative, et un état. La
 *  carte les montre dans cet ordre — parce que c'est l'ordre dans lequel on
 *  décide : *qu'est-ce que c'est, est-ce que je peux, où je l'achète.*
 *
 *  Ce qui n'apparaît jamais : **qui** a réservé. Un souhait réservé se dit réservé,
 *  et rien de plus (dictionnaire, `WishReservation`) — sauf au visiteur qui
 *  revient avec son jeton et retrouve les siens.
 *
 *  L'anonymat de la réservation se dit **une fois**, en pied de liste — pas sur chaque
 *  carte : répété quatre fois, un rappel devient du bruit.
 *
 *  Le lien est **affiché en clair** (le domaine) : le visiteur voit où il va avant
 *  de cliquer, et il s'ouvre en isolation (§9.7 de la spéc. technique).
 *
 *  `etat` : `libre` · `reserve` · `mien` (réservé par moi) · `offert`.
 *  Deux chemins de réservation : un utilisateur connecté réserve **en un geste**
 *  (`connecte`), un visiteur sans compte laisse une adresse et confirme par code. */
export function WishCard({ t, souhait, connecte = false, onReserver, onAnnuler }) {
  const p = t.souhait;
  const [etape, setEtape] = React.useState(null); // null | "coordonnees" | "code"
  const [nom, setNom] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [code, setCode] = React.useState("");
  const [connu, setConnu] = React.useState(true);
  const s = souhait;
  const eteint = s.etat === "offert";

  const commencer = () => {
    if (connecte) return onReserver && onReserver(s);
    setEtape("coordonnees");
  };

  return (
    <div style={{
      background: "var(--surface-card)", border: "1px solid var(--border-object)",
      borderRadius: "var(--radius-xl)", padding: 16,
      opacity: eteint ? .62 : 1
    }}>
      <div style={{ display: "flex", gap: 14, alignItems: "flex-start" }}>
        {s.image ? (
          <img src={s.image} alt="" style={{
            width: 68, height: 68, flex: "none", objectFit: "cover",
            borderRadius: "var(--radius-md)", background: "var(--surface-panel)"
          }} />
        ) : null}

        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{
            display: "flex", gap: 10, alignItems: "baseline", flexWrap: "wrap"
          }}>
            <span style={{
              fontSize: 16.5, fontWeight: 600, lineHeight: 1.35,
              textDecoration: eteint ? "line-through" : "none"
            }}>{s.label}</span>
            {s.prix ? (
              <span style={{
                fontFamily: "var(--font-display)",
                fontVariationSettings: "var(--font-display-settings)",
                fontWeight: 500, fontSize: 16, letterSpacing: "-.015em",
                color: "var(--text-accent)", whiteSpace: "nowrap"
              }}>{s.prix}</span>
            ) : null}
          </div>

          {s.details ? (
            <p style={{
              margin: "5px 0 0", fontSize: 14.5, lineHeight: 1.5,
              color: "var(--text-secondary)", textWrap: "pretty"
            }}>{s.details}</p>
          ) : null}

          {s.lien ? (
            <a href={s.lienUrl || "#"} target="_blank" rel="noopener noreferrer" style={{
              display: "inline-flex", alignItems: "center", gap: 5, marginTop: 8,
              fontSize: 13.5, color: "var(--text-accent)", textDecoration: "none",
              wordBreak: "break-all"
            }}>
              <Icon name="external-link" size={13} />
              {s.lien}
            </a>
          ) : null}
        </div>
      </div>

      <div style={{
        marginTop: 14, paddingTop: 12, borderTop: "1px solid var(--border-hairline)",
        display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap"
      }}>
        {s.etat === "libre" && etape === null ? (
          <Button variant="outline" onClick={commencer}>{p.reserver}</Button>
        ) : null}

        {s.etat === "reserve" ? (
          <>
            <Tag>{p.reserve}</Tag>
            <span style={{ fontSize: 13, color: "var(--text-mention)" }}>{p.reserveAide}</span>
          </>
        ) : null}

        {s.etat === "mien" ? (
          <>
            <Tag tone="quiet">{p.mien}</Tag>
            <button type="button" onClick={() => onAnnuler && onAnnuler(s)}
              className="lehno-focusable" style={{
                all: "unset", cursor: "pointer", fontFamily: "var(--font-body)",
                fontSize: 13.5, color: "var(--text-secondary)", textDecoration: "underline"
              }}>{p.annuler}</button>
          </>
        ) : null}

        {s.etat === "offert" ? <Tag>{p.offert}</Tag> : null}
      </div>

      {etape === "coordonnees" ? (
        <div style={{ marginTop: 14, display: "grid", gap: 14 }}>
          <p style={{
            margin: 0, fontSize: 14, color: "var(--text-secondary)", textWrap: "pretty"
          }}>{p.pourquoiAdresse}</p>
          <TextField label={p.labelEmail} type="email" value={email}
            onChange={(e) => setEmail(e.target.value)} />
          <label style={{
            display: "flex", gap: 10, alignItems: "flex-start", fontSize: 14.5,
            color: "var(--text-body)", cursor: "pointer"
          }}>
            <input type="checkbox" checked={connu} onChange={(e) => setConnu(e.target.checked)}
              className="lehno-focusable" style={{ marginTop: 3, accentColor: "var(--action)" }} />
            <span style={{ textWrap: "pretty" }}>{p.seFaireConnaitre}</span>
          </label>
          {connu ? (
            <TextField label={p.labelNom} value={nom} onChange={(e) => setNom(e.target.value)} />
          ) : null}
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <Button disabled={!email} onClick={() => setEtape("code")}>{p.continuer}</Button>
            <Button variant="text" onClick={() => setEtape(null)}>{p.annulerGeste}</Button>
          </div>
        </div>
      ) : null}

      {etape === "code" ? (
        <div style={{ marginTop: 14, display: "grid", gap: 14 }}>
          <p style={{
            margin: 0, fontSize: 14, color: "var(--text-secondary)", textWrap: "pretty"
          }}>{p.codeEnvoye}</p>
          <TextField label={p.labelCode} value={code} inputMode="numeric"
            onChange={(e) => setCode(e.target.value)} />
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <Button disabled={code.length < 4}
              onClick={() => { setEtape(null); onReserver && onReserver(s, { nom: connu ? nom : null }); }}>
              {p.confirmer}
            </Button>
            <Button variant="text" onClick={() => setEtape(null)}>{p.annulerGeste}</Button>
          </div>
        </div>
      ) : null}
    </div>
  );
}
