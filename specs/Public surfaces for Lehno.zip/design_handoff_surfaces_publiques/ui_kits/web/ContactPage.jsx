import React from "react";
import { Button } from "../../components/core/Button.jsx";
import { Icon } from "../../components/core/Icon.jsx";
import { SocialGlyph } from "../../components/brand/SocialGlyph.jsx";
import { TextField } from "../../components/forms/TextField.jsx";
import { Banner } from "../../components/feedback/Banner.jsx";

/** Gabarit contact — un formulaire et les comptes publics. Deux canaux, pas six :
 *  une liste de moyens de contact est une liste de promesses. */
export function ContactPage({ t, base = "../../" }) {
  const p = t.contact;
  const [envoye, setEnvoye] = React.useState(false);
  const [champs, setChamps] = React.useState({ nom: "", email: "", message: "" });
  const [sujet, setSujet] = React.useState(p.sujets[0]);
  const emailInvalide = champs.email.length > 0 && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(champs.email);
  const complet = champs.nom.trim() && champs.email && !emailInvalide && champs.message.trim().length > 9;

  const maj = (cle) => (e) => setChamps((c) => ({ ...c, [cle]: e.target.value }));

  return (
    <div style={{
      maxWidth: "var(--page-max)", margin: "0 auto",
      padding: "clamp(40px,5vw,68px) var(--page-gutter) clamp(52px,7vw,92px)"
    }}>
      <header style={{ marginBottom: 40, maxWidth: "62ch" }}>
        <div style={{
          fontSize: 11, fontWeight: 700, letterSpacing: ".14em", textTransform: "uppercase",
          color: "var(--text-mention)", marginBottom: 12
        }}>{p.kicker}</div>
        <h1 style={{
          margin: 0, fontFamily: "var(--font-display)",
          fontVariationSettings: "var(--font-display-settings)",
          fontWeight: 400, fontSize: "clamp(34px,4.4vw,52px)", lineHeight: 1.05,
          letterSpacing: "-.025em", textWrap: "balance"
        }}>{p.titre}</h1>
        <p style={{
          margin: "16px 0 0", fontSize: 17, lineHeight: 1.6,
          color: "var(--text-secondary)", textWrap: "pretty"
        }}>{p.chapeau}</p>
      </header>

      <div className="contact-grid" style={{
        display: "grid", gridTemplateColumns: "minmax(0,1fr) 300px",
        gap: "clamp(30px,5vw,64px)", alignItems: "start"
      }}>
        <div style={{ maxWidth: 560 }}>
          {envoye ? (
            <div style={{ marginBottom: 20 }}>
              <Banner intent="success" onDismiss={() => setEnvoye(false)}>{p.confirme}</Banner>
            </div>
          ) : null}

          <form onSubmit={(e) => { e.preventDefault(); setEnvoye(true); }}
            style={{ display: "grid", gap: 18 }}>
            <TextField label={p.labelNom} value={champs.nom} onChange={maj("nom")}
              autoComplete="name" />
            <TextField label={p.labelEmail} type="email" value={champs.email}
              onChange={maj("email")} invalid={emailInvalide} autoComplete="email"
              hint={emailInvalide ? p.emailErreur : undefined} />

            <div style={{ display: "grid", gap: 6, fontFamily: "var(--font-body)" }}>
              <label htmlFor="contact-sujet" style={{
                fontSize: "var(--text-body-xs)", color: "var(--text-secondary)"
              }}>{p.labelSujet}</label>
              <select id="contact-sujet" value={sujet} onChange={(e) => setSujet(e.target.value)}
                className="lehno-focusable" style={{
                  boxSizing: "border-box", width: "100%", fontFamily: "var(--font-body)",
                  fontSize: "var(--text-body-m)", color: "var(--text-body)",
                  background: "var(--surface-card)", border: "1px solid var(--border-object)",
                  borderRadius: "var(--radius-sm)", padding: "14px 15px"
                }}>
                {p.sujets.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>

            <TextField label={p.labelMessage} multiline rows={6} value={champs.message}
              onChange={maj("message")} hint={p.aideMessage} />

            <div style={{ display: "flex", gap: 14, alignItems: "center", flexWrap: "wrap" }}>
              <Button type="submit" disabled={!complet}>{p.envoyer}</Button>
              <span style={{ fontSize: 12.5, color: "var(--text-mention)" }}>{p.delai}</span>
            </div>
          </form>
        </div>

        <aside style={{
          background: "var(--surface-panel)", border: "1px solid var(--border-hairline)",
          borderRadius: "var(--radius-2xl)", padding: "22px 24px"
        }}>
          <h2 style={{
            margin: "0 0 4px", fontFamily: "var(--font-display)",
            fontVariationSettings: "var(--font-display-settings)",
            fontWeight: 500, fontSize: 21, letterSpacing: "-.015em"
          }}>{p.reseauxTitre}</h2>
          <p style={{
            margin: "0 0 16px", fontSize: 14.5, lineHeight: 1.55,
            color: "var(--text-secondary)", textWrap: "pretty"
          }}>{p.reseauxTexte}</p>
          <div style={{ display: "grid", gap: 2 }}>
            {p.reseaux.map((r) => (
              <a key={r.nom} href={r.url} target="_blank" rel="noopener noreferrer" style={{
                display: "flex", alignItems: "center", gap: 11, minHeight: 44,
                padding: "6px 0", textDecoration: "none", color: "var(--text-body)",
                fontSize: 15, borderTop: "1px solid var(--border-hairline)"
              }}>
                <SocialGlyph reseau={r.nom} size={17} color="var(--text-secondary)" base={base} />
                <span style={{ flex: 1, minWidth: 0 }}>{r.compte}</span>
                <Icon name="arrow-up-right" size={15} color="var(--text-mention)" />
              </a>
            ))}
          </div>
        </aside>
      </div>
    </div>
  );
}
