import React from "react";
import { Avatar } from "../../components/core/Avatar.jsx";
import { Tag } from "../../components/core/Tag.jsx";
import { Button } from "../../components/core/Button.jsx";
import { Card } from "../../components/core/Card.jsx";
import { SectionLabel } from "../../components/core/SectionLabel.jsx";
import { Icon } from "../../components/core/Icon.jsx";
import { WishCard } from "./WishCard.jsx";

/** Le Mur — la page publique d'un utilisateur, servie à son adresse.
 *
 *  Ici c'est le propriétaire qui parle à ses proches : « je », tutoiement. C'est
 *  la seule surface où la marque ne parle pas en son nom.
 *
 *  Trois règles que la page tient :
 *  - **La liste s'ouvre d'un geste**, elle ne s'étale pas : un visiteur venu dire
 *    bonjour n'a pas à tomber sur une liste de cadeaux.
 *  - **Pas de livre d'or.** Les vœux reçus vont au propriétaire et ne s'affichent
 *    jamais ici.
 *  - **Pas de mention « créé avec Lehno ».** Le Mur est déjà servi à l'adresse de
 *    Lehno ; seule l'invitation compte. */
export function WallPage({ t, nuit, base = "../../", connecte = false }) {
  const [ouverte, setOuverte] = React.useState(false);
  const [souhaits, setSouhaits] = React.useState(t.murSouhaits);

  React.useEffect(() => { setSouhaits(t.murSouhaits); }, [t]);

  const majEtat = (cible, etat) =>
    setSouhaits((l) => l.map((s) => (s.label === cible.label ? { ...s, etat } : s)));

  const libres = souhaits.filter((s) => s.etat === "libre").length;

  return (
    <div style={{ maxWidth: 520, margin: "0 auto", padding: "0 var(--page-gutter) 56px" }}>
      <div style={{
        background: "var(--surface-panel)", borderRadius: "0 0 var(--radius-2xl) var(--radius-2xl)",
        padding: "40px 26px 32px", textAlign: "center"
      }}>
        <Avatar name="Valentine" src={base + "assets/valentine.png"} size={76} style={{ margin: "0 auto 14px" }} />
        <h1 className="lehno-display" style={{
          fontSize: 27, letterSpacing: "-.02em", margin: 0, lineHeight: 1.25
        }}>{t.murTitre}</h1>
        <div className="lehno-parole" style={{
          fontSize: 15.5, color: "var(--text-secondary)", marginTop: 8
        }}>{t.murSous}</div>
      </div>

      <div style={{ padding: "26px 4px 0" }}>
        <SectionLabel>{t.murGoutsLabel}</SectionLabel>
        <div style={{ display: "flex", gap: 7, flexWrap: "wrap", marginTop: 10 }}>
          {t.murTags.map((g) => <Tag key={g}>{g}</Tag>)}
        </div>

        <div style={{ fontSize: 14.5, color: "var(--text-secondary)", marginTop: 20 }}>{t.murDate}</div>

        {ouverte ? (
          <section style={{ marginTop: 24 }}>
            <div style={{
              display: "flex", alignItems: "baseline", gap: 10, flexWrap: "wrap", marginBottom: 12
            }}>
              <SectionLabel>{t.murListeLabel}</SectionLabel>
              <span style={{
                marginLeft: "auto", fontSize: 12.5, color: "var(--text-mention)"
              }}>{libres + " " + (libres > 1 ? t.murLibresPluriel : t.murLibresSingulier)}</span>
            </div>
            <div style={{ display: "grid", gap: 10 }}>
              {souhaits.map((s) => (
                <WishCard key={s.label} t={t} souhait={s} connecte={connecte}
                  onReserver={(cible) => majEtat(cible, "mien")}
                  onAnnuler={(cible) => majEtat(cible, "libre")} />
              ))}
            </div>
            <p style={{
              margin: "14px 0 0", fontSize: 12.5, color: "var(--text-mention)", textWrap: "pretty"
            }}>{t.murListePied}</p>
          </section>
        ) : (
          <Card padding={18} radius="lg" style={{ marginTop: 20, borderColor: "var(--action-edge)" }}>
            <div style={{ fontSize: 15, textWrap: "pretty" }}>{t.murListeTexte}</div>
            <Button variant="outline" full style={{ marginTop: 14 }}
              onClick={() => setOuverte(true)} iconAfter="chevron-down">
              {t.murListeCta}
            </Button>
          </Card>
        )}

        <Card padding={18} radius="lg" style={{ marginTop: 12 }}>
          <SectionLabel>{t.murMotLabel}</SectionLabel>
          <div style={{ fontSize: 15, marginTop: 8, textWrap: "pretty" }}>{t.murMotTexte}</div>
          <Button full style={{ marginTop: 14 }}>{t.murMotCta}</Button>
          <div style={{
            display: "flex", gap: 7, alignItems: "center", marginTop: 10,
            fontSize: 12.5, color: "var(--text-mention)"
          }}>
            <Icon name="lock" size={13} />
            {t.murMotPrive}
          </div>
        </Card>

        <div style={{
          marginTop: 32, paddingTop: 22, borderTop: "1px solid var(--border-hairline)",
          display: "grid", gap: 10, justifyItems: "center"
        }}>
          <Button variant="text">{t.murPied}</Button>
          {/* Le signalement est prévu au modèle (file de modération du back-office,
              §6 des surfaces publiques) : il faut donc qu'un visiteur puisse le faire
              depuis la page. Discret, mais présent — sinon la FAQ promet une
              affordance qui n'existe pas. */}
          <a href="#" style={{
            fontSize: 12.5, color: "var(--text-mention)", textDecoration: "none"
          }}>{t.murSignaler}</a>
        </div>
      </div>
    </div>
  );
}
