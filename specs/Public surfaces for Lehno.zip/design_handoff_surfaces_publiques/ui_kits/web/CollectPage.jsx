import React from "react";
import { Button } from "../../components/core/Button.jsx";
import { Icon } from "../../components/core/Icon.jsx";
import { Tag } from "../../components/core/Tag.jsx";
import { TextField } from "../../components/forms/TextField.jsx";
import { Banner } from "../../components/feedback/Banner.jsx";
import { Provenance } from "../../components/content/Provenance.jsx";
import { Avatar } from "../../components/core/Avatar.jsx";

/** Collecte — silhouette « conversation, puis formulaire ».
 *
 *  L'objectif est qu'un proche réponde vite et bien, sans se sentir interrogé.
 *  La page ouvre donc sur **qui demande et pourquoi**, et le formulaire vient
 *  après, resserré. Le titre est moyen, pas héroïque : ce n'est pas une page qui
 *  séduit, c'est un service qu'on rend à quelqu'un.
 *
 *  **Deux ouvertures, et il faut savoir laquelle on montre.** Par défaut, la phrase
 *  d'ouverture est du **texte de produit**, composé du prénom du propriétaire, en
 *  romain et au vouvoiement : le produit parle. La prop `mot` affiche à la place le
 *  **mot du propriétaire lui-même** — et là seulement, l'italique et le tutoiement
 *  sont légitimes, avec sa signature dessous, parce que ce sont ses mots.
 *
 *  `CollectionLink` n'a pas encore de champ pour ce mot : l'afficher demande
 *  d'ajouter `invitation_message` (text, nullable) au dictionnaire. En attendant,
 *  aucune page ne doit composer une fausse citation du propriétaire — mettre en
 *  italique une phrase qu'il n'a pas écrite lui fait dire ce qu'il n'a pas dit.
 *
 *  Deux variantes : `nominatif` (le propriétaire sait qui il invite, la fiche
 *  existe, la date est parfois pré-remplie) et `public` (n'importe qui répond,
 *  d'où deux champs de plus : son nom et « on se connaît d'où »).
 *
 *  **Pas de champ « pseudo Lehno ».** La spec le prévoit en facultatif, mais demander
 *  son pseudo à quelqu'un sur un formulaire public, c'est un champ de plus pour un
 *  rattachement auto-déclaré, invérifiable, que la plupart des répondants ne peuvent
 *  pas remplir. Le rattachement viendra du lien profond : ouvrir le lien depuis
 *  l'application identifie le répondant sans rien lui demander.
 *
 *  **La photo demande un champ au modèle.** `WishlistItem` porte bien `image_url`
 *  (la liste du Mur l'affiche), mais `SubmittedWish` non : recueillir la photo ici
 *  suppose d'ajouter `image_url` au dictionnaire, et d'appliquer les règles du §9.6
 *  de la spéc. technique — type réel vérifié d'après le contenu, poids et dimensions
 *  bornés, image recomposée, métadonnées retirées (dont la position géographique),
 *  servie depuis un domaine distinct.
 *
 *  Le lien ne meurt pas : à la réouverture, le répondant retrouve ce qu'il a
 *  déjà envoyé **avec son sort** — retenu ou écarté. C'est la seule surface
 *  publique où l'on montre une décision du propriétaire, et elle se montre sans
 *  la commenter. */
export function CollectPage({ t, variante = "nominatif", dejaEnvoye = false, motProprietaire = null }) {
  const p = t.collecte;
  const pub = variante === "public";
  const [envoye, setEnvoye] = React.useState(false);
  const [date, setDate] = React.useState(pub ? "" : "1994-05-21");
  const [souhaits, setSouhaits] = React.useState([{ label: "", prix: "", lien: "", photo: null, ouvert: false }]);
  const [mot, setMot] = React.useState("");
  const [nom, setNom] = React.useState("");
  const [relation, setRelation] = React.useState("");
  const [email, setEmail] = React.useState("");

  const utile = date || souhaits.some((s) => s.label.trim()) || mot.trim();
  const complet = utile && (!pub || nom.trim());

  const majPhoto = (i) => (e) => {
    const f = e.target.files && e.target.files[0];
    setSouhaits((l) => l.map((s, j) => (j === i ? { ...s, photo: f ? URL.createObjectURL(f) : null } : s)));
  };
  const retirerPhoto = (i) =>
    setSouhaits((l) => l.map((s, j) => (j === i ? { ...s, photo: null } : s)));

  const majSouhait = (i, cle) => (e) =>
    setSouhaits((l) => l.map((s, j) => (j === i ? { ...s, [cle]: e.target.value } : s)));
  const basculer = (i) =>
    setSouhaits((l) => l.map((s, j) => (j === i ? { ...s, ouvert: !s.ouvert } : s)));

  if (envoye) {
    return (
      <>
        <div style={{ marginBottom: 22 }}>
          <Banner intent="success">{p.confirmeTitre}</Banner>
        </div>
        <p style={{
          margin: "0 0 18px", fontSize: 17, lineHeight: 1.6, textWrap: "pretty"
        }}>{p.confirmeTexte}</p>
        <p style={{
          margin: 0, fontSize: 15, color: "var(--text-secondary)", textWrap: "pretty"
        }}>{p.confirmeRevenir}</p>
        <div style={{ marginTop: 22 }}>
          <Button variant="outline" onClick={() => setEnvoye(false)}>{p.ajouterEncore}</Button>
        </div>
      </>
    );
  }

  return (
    <>
      <header style={{ marginBottom: 30 }}>
        {/* Un lien nominatif désigne une personne précise (CollectionLink.person_id) :
            la page le dit, avec le nom tel que le propriétaire l'a enregistré. Sans
            ça, un lien nominatif et un lien public se ressemblent — et le répondant
            ne sait pas si c'est bien à lui qu'on parle. */}
        {/* On salue d'abord la personne — un lien nominatif désigne quelqu'un
            (CollectionLink.person_id) —, et c'est seulement après qu'on dit de qui
            vient l'invitation. L'inverse, c'est une machine qui se présente avant
            de dire bonjour. */}
        <h1 style={{
          margin: 0, fontFamily: "var(--font-display)",
          fontVariationSettings: "var(--font-display-settings)",
          fontWeight: 400, fontSize: "clamp(27px,3.6vw,37px)", lineHeight: 1.08,
          letterSpacing: "-.028em", textWrap: "balance"
        }}>{!pub && p.destinataire ? p.salut + " " + p.destinataire : p.salutPublic}</h1>

        <div style={{
          display: "flex", alignItems: "center", gap: 12, marginTop: 18
        }}>
          <Avatar name={p.demandeur} size={42} />
          <div style={{ minWidth: 0 }}>
            <div style={{ fontSize: 15.5, fontWeight: 600 }}>{p.demandeur}</div>
            <div style={{ fontSize: 13.5, color: "var(--text-mention)" }}>
              {pub ? p.demandeMentionPublic : p.demandeMentionNominatif}
            </div>
          </div>
        </div>

        {motProprietaire ? (
          <div style={{
            marginTop: 20, paddingLeft: 16, borderLeft: "2px solid var(--action-edge)"
          }}>
            <div className="lehno-parole" style={{
              fontSize: "clamp(20px,2.4vw,25px)", lineHeight: 1.4,
              letterSpacing: "-.01em", maxWidth: "32ch", textWrap: "pretty"
            }}>{motProprietaire}</div>
            <div style={{
              marginTop: 8, fontSize: 13.5, color: "var(--text-mention)"
            }}>{"— " + p.demandeur}</div>
          </div>
        ) : null}

        <p style={{
          margin: "14px 0 0", fontSize: "clamp(17px,1.7vw,19px)", lineHeight: 1.55,
          color: "var(--text-secondary)", maxWidth: "44ch", textWrap: "pretty"
        }}>{dejaEnvoye ? p.chapeauRetour : (pub ? p.chapeauPublic : p.chapeauNominatif)}</p>
      </header>

      <form onSubmit={(e) => { e.preventDefault(); setEnvoye(true); }}
        style={{ display: "grid", gap: 22 }}>
        {pub ? (
          <>
            <TextField label={p.labelNom} value={nom} onChange={(e) => setNom(e.target.value)} />
            <TextField label={p.labelRelation} hint={p.aideRelation}
              value={relation} onChange={(e) => setRelation(e.target.value)} />
          </>
        ) : null}

        <TextField label={p.labelDate} type="date" value={date}
          onChange={(e) => setDate(e.target.value)}
          hint={dejaEnvoye ? p.aideDateDeja : (pub ? p.aideDatePublic : p.aideDateNominatif)} />

        <div style={{ display: "grid", gap: 10 }}>
          <div style={{ fontSize: "var(--text-body-xs)", color: "var(--text-secondary)" }}>
            {p.labelSouhaits}
          </div>

          {/* Ce qu'on a déjà envoyé se range ici, et pas en tête de page : c'est un
              historique de **ce champ**. Il évite de proposer deux fois la même chose,
              donc il doit se lire juste avant d'écrire — pas trois écrans plus haut.
              Le sort de chaque souhait se montre sans le commenter : « écarté » ne
              s'excuse pas et ne se justifie pas. */}
          {dejaEnvoye ? (
            <div style={{
              background: "var(--surface-panel)", border: "1px solid var(--border-hairline)",
              borderRadius: "var(--radius-lg)", padding: "12px 14px"
            }}>
              <div style={{
                fontSize: 11, fontWeight: 700, letterSpacing: ".12em", textTransform: "uppercase",
                color: "var(--text-mention)", marginBottom: 2
              }}>{p.dejaTitre}</div>
              <div style={{ display: "grid" }}>
                {p.deja.map((d) => (
                  <div key={d.quoi} style={{
                    display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap",
                    padding: "9px 0", borderBottom: "1px solid var(--border-hairline)"
                  }}>
                    <span style={{ flex: 1, minWidth: 0, fontSize: 15.5 }}>{d.quoi}</span>
                    <Tag tone={d.retenu ? "quiet" : "outline"}>{d.retenu ? p.retenu : p.ecarte}</Tag>
                  </div>
                ))}
              </div>
              <div style={{ marginTop: 10 }}>
                <Provenance origin={p.dejaProvenance} date={p.dejaDate} />
              </div>
            </div>
          ) : null}
          {souhaits.map((s, i) => (
            <div key={i} style={{
              border: "1px solid var(--border-hairline)", borderRadius: "var(--radius-lg)",
              padding: 12, display: "grid", gap: 10
            }}>
              <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <TextField value={s.label} onChange={majSouhait(i, "label")}
                    placeholder={p.placeholderSouhait} />
                </div>
                {!s.ouvert ? (
                  <Button variant="text" onClick={() => basculer(i)}>{p.preciser}</Button>
                ) : null}
                {souhaits.length > 1 ? (
                  <button type="button" className="lehno-focusable"
                    onClick={() => setSouhaits((l) => l.filter((_, j) => j !== i))}
                    aria-label={p.retirerSouhait}
                    style={{
                      all: "unset", cursor: "pointer", display: "grid", placeItems: "center",
                      width: 40, height: 40, flex: "none", borderRadius: "var(--radius-sm)",
                      color: "var(--text-mention)"
                    }}>
                    <Icon name="x" size={16} />
                  </button>
                ) : null}
              </div>

              {s.ouvert ? (
                <div style={{ display: "grid", gap: 12, paddingTop: 2 }}>
                  <TextField label={p.labelPrecisions} multiline rows={2}
                    value={s.details || ""} onChange={majSouhait(i, "details")}
                    hint={p.aidePrecisions} />
                  <div style={{
                    display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(140px,1fr))", gap: 12
                  }}>
                    <TextField label={p.labelPrix} value={s.prix} onChange={majSouhait(i, "prix")}
                      inputMode="numeric" placeholder={p.placeholderPrix} />
                    <TextField label={p.labelLien} value={s.lien} onChange={majSouhait(i, "lien")}
                      type="url" placeholder={p.placeholderLien} />
                  </div>

                  {/* La photo est ce qui lève le plus de doutes : « le bleu indigo,
                      pas le turquoise » se règle mieux en une image qu'en une phrase.
                      Sur téléphone, l'appareil photo s'ouvre directement (capture). */}
                  <div>
                    <div style={{
                      fontSize: "var(--text-body-xs)", color: "var(--text-secondary)", marginBottom: 6
                    }}>{p.labelPhoto}</div>
                    {s.photo ? (
                      <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                        <img src={s.photo} alt="" style={{
                          width: 76, height: 76, objectFit: "cover",
                          borderRadius: "var(--radius-md)", border: "1px solid var(--border-object)"
                        }} />
                        <Button variant="text" onClick={() => retirerPhoto(i)}>{p.retirerPhoto}</Button>
                      </div>
                    ) : (
                      <label className="lehno-focusable" style={{
                        display: "inline-flex", alignItems: "center", gap: 9, cursor: "pointer",
                        minHeight: 44, padding: "0 14px",
                        border: "1px dashed var(--border-object)", borderRadius: "var(--radius-md)",
                        fontSize: 14.5, color: "var(--text-secondary)"
                      }}>
                        <Icon name="camera" size={16} />
                        {p.ajouterPhoto}
                        <input type="file" accept="image/*" capture="environment"
                          onChange={majPhoto(i)} style={{
                            position: "absolute", width: 1, height: 1, opacity: 0, pointerEvents: "none"
                          }} />
                      </label>
                    )}
                    <div style={{
                      fontSize: "var(--text-mention-s)", color: "var(--text-mention)", marginTop: 6
                    }}>{p.aidePhoto}</div>
                  </div>
                </div>
              ) : null}
            </div>
          ))}
          <div>
            <Button variant="text" icon="plus" onClick={() => setSouhaits((l) => [...l, { label: "", prix: "", lien: "", photo: null, ouvert: false }])}>
              {p.ajouterSouhait}
            </Button>
          </div>
        </div>

        <TextField label={p.labelMot} multiline rows={4} value={mot}
          onChange={(e) => setMot(e.target.value)}
          hint={dejaEnvoye ? p.aideMotDeja : p.aideMot} />

        <div style={{
          paddingTop: 18, borderTop: "1px solid var(--border-hairline)",
          display: "grid", gap: 22
        }}>
          <div style={{
            fontSize: 11, fontWeight: 700, letterSpacing: ".14em", textTransform: "uppercase",
            color: "var(--text-mention)"
          }}>{p.facultatif}</div>
          <TextField label={p.labelEmail} type="email" value={email}
            onChange={(e) => setEmail(e.target.value)} hint={p.aideEmail} />
        </div>

        <div>
          <Button type="submit" disabled={!complet}>{p.envoyer}</Button>
        </div>
      </form>
    </>
  );
}
