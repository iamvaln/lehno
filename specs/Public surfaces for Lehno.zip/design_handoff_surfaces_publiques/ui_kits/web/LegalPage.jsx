import React from "react";
import { ARediger } from "./ARediger.jsx";

/** Gabarit légal — un texte long qui se consulte, pas qui se lit d'un trait.
 *  Sommaire collant à gauche, corps à 62ch, un titre par obligation.
 *  `sections` : [{ id, titre, couvre }]. `procedure` : une liste ordonnée
 *  quand la page décrit une démarche (suppression de compte). */
export function LegalPage({ t, page }) {
  const p = t[page];
  const [vue, setVue] = React.useState(p.sections[0] && p.sections[0].id);

  React.useEffect(() => {
    const cibles = p.sections.map((s) => document.getElementById(s.id)).filter(Boolean);
    if (!cibles.length) return;
    const obs = new IntersectionObserver(
      (entrees) => {
        const visible = entrees.filter((e) => e.isIntersecting)
          .sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top)[0];
        if (visible) setVue(visible.target.id);
      },
      { rootMargin: "-88px 0px -70% 0px" }
    );
    cibles.forEach((c) => obs.observe(c));
    return () => obs.disconnect();
  }, [page]);

  return (
    <div style={{
      maxWidth: "var(--page-max)", margin: "0 auto",
      padding: "clamp(40px,5vw,68px) var(--page-gutter) clamp(52px,7vw,92px)"
    }}>
      <header style={{ marginBottom: 34 }}>
        <div style={{
          fontSize: 11, fontWeight: 700, letterSpacing: ".14em", textTransform: "uppercase",
          color: "var(--text-mention)", marginBottom: 12
        }}>{p.kicker}</div>
        <h1 style={{
          margin: 0, fontFamily: "var(--font-display)",
          fontVariationSettings: "var(--font-display-settings)",
          fontWeight: 400, fontSize: "clamp(34px,4.4vw,52px)", lineHeight: 1.05,
          letterSpacing: "-.025em", textWrap: "balance", maxWidth: "22ch"
        }}>{p.titre}</h1>
        <p style={{
          margin: "16px 0 0", fontSize: 17, lineHeight: 1.6,
          color: "var(--text-secondary)", maxWidth: "62ch", textWrap: "pretty"
        }}>{p.chapeau}</p>
        <div style={{
          marginTop: 16, paddingTop: 12, borderTop: "1px solid var(--border-hairline)",
          display: "flex", gap: 8, alignItems: "baseline",
          fontSize: 11.5, color: "var(--text-mention)"
        }}>
          <span>{p.majLabel}</span>
          <span>·</span>
          <span>{p.maj}</span>
        </div>
      </header>

      <div className="legal-grid" style={{
        display: "grid", gridTemplateColumns: "216px minmax(0,1fr)",
        gap: "clamp(28px,5vw,64px)", alignItems: "start"
      }}>
        <nav className="legal-somm" style={{ position: "sticky", top: 88 }}>
          <div style={{
            fontSize: 10.5, fontWeight: 700, letterSpacing: ".14em", textTransform: "uppercase",
            color: "var(--text-mention)", marginBottom: 10
          }}>{t.sommaire}</div>
          <div style={{ display: "grid", gap: 2 }}>
            {p.sections.map((s) => {
              const on = s.id === vue;
              return (
                <a key={s.id} href={"#" + s.id} style={{
                  display: "block", padding: "5px 0 5px 11px",
                  borderLeft: "2px solid " + (on ? "var(--action)" : "var(--border-hairline)"),
                  color: on ? "var(--text-accent)" : "var(--text-secondary)",
                  fontWeight: on ? 600 : 400, fontSize: 14, lineHeight: 1.35,
                  textDecoration: "none", transition: "color var(--transition-state)"
                }}>{s.titre}</a>
              );
            })}
          </div>
        </nav>

        <div style={{ minWidth: 0 }}>
          {p.procedure ? (
            <ol style={{
              margin: "0 0 38px", padding: 0, listStyle: "none",
              display: "grid", gap: 14, counterReset: "etape"
            }}>
              {p.procedure.map((e, i) => (
                <li key={i} style={{ display: "flex", gap: 14, alignItems: "flex-start" }}>
                  <span style={{
                    flex: "none", width: 27, height: 27, borderRadius: 999,
                    display: "grid", placeItems: "center",
                    background: "var(--surface-panel)", color: "var(--text-accent)",
                    fontFamily: "var(--font-display)", fontWeight: 500, fontSize: 14
                  }}>{i + 1}</span>
                  <p style={{
                    margin: 0, paddingTop: 3, fontSize: 16, lineHeight: 1.6,
                    maxWidth: "58ch", textWrap: "pretty"
                  }}>{e}</p>
                </li>
              ))}
            </ol>
          ) : null}

          {p.sections.map((s) => (
            <section key={s.id} id={s.id} style={{
              paddingTop: 4, marginBottom: 34, scrollMarginTop: 88
            }}>
              <h2 style={{
                margin: "0 0 4px", fontFamily: "var(--font-display)",
                fontVariationSettings: "var(--font-display-settings)",
                fontWeight: 500, fontSize: 23, lineHeight: 1.2,
                letterSpacing: "-.015em", textWrap: "balance"
              }}>{s.titre}</h2>
              <ARediger couvre={s.couvre} label={t.aRediger} qui={t.quiRedige} />
            </section>
          ))}

          <div style={{
            marginTop: 40, paddingTop: 18, borderTop: "1px solid var(--border-hairline)",
            fontSize: 13.5, color: "var(--text-mention)", maxWidth: "62ch", textWrap: "pretty"
          }}>{p.pied}</div>
        </div>
      </div>
    </div>
  );
}
