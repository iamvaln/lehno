import React from "react";
import { SiteHeader } from "./SiteHeader.jsx";
import { SiteFooter } from "./SiteFooter.jsx";
import { Icon } from "../../components/core/Icon.jsx";
import { Button } from "../../components/core/Button.jsx";

/** La coquille des surfaces publiques.
 *
 *  Ce sont des pages du **même site** que la landing : elles portent donc le même
 *  en-tête (avec sa navigation et son menu sous 880 px) et le **même pied**. Une
 *  page atteinte par un lien n'est pas un autre produit — un visiteur qui découvre
 *  Lehno par le Mur d'une amie doit pouvoir aller voir ce qu'est Lehno, et revenir.
 *
 *  Ce qui change d'une page à l'autre, c'est la **silhouette du contenu**, pas le
 *  cadre : `largeur` pour les pages qui se lisent en colonne, `pleinePage` pour celles
 *  qui composent leurs propres bandes et posent donc elles-mêmes leur conteneur.
 *
 *  L'aplat de clôture est celui de la landing — mêmes couleurs, même bouton
 *  abricot. Il porte le CTA d'acquisition que la spec veut sur toutes les pages
 *  publiques. */
export function PublicShell({
  t, langue = "fr", nuit, onTheme, onLangue, base = "../../",
  largeur = 620, pleinePage = false, murLien, onMur, onLegal,
  acquisition = true, consentement = true, children
}) {
  const [consenti, setConsenti] = React.useState(!consentement);
  return (
    <>
      <SiteHeader t={t} nuit={nuit} base={base} langue={langue} ancres="index.html"
        onTheme={onTheme} onLangue={onLangue} />

      <main>
        {pleinePage ? children : (
          <div style={{
            width: "100%", maxWidth: largeur, margin: "0 auto", boxSizing: "border-box",
            padding: "clamp(32px,5vw,60px) var(--page-gutter) clamp(40px,6vw,72px)"
          }}>{children}</div>
        )}

        {murLien ? (
          <div style={{
            maxWidth: largeur, margin: "0 auto", boxSizing: "border-box",
            padding: "0 var(--page-gutter) 40px"
          }}>
            <a href="#" onClick={(e) => { e.preventDefault(); onMur && onMur(); }}
              style={{
                display: "inline-flex", alignItems: "center", gap: 7,
                fontSize: 15, color: "var(--text-accent)", textDecoration: "none"
              }}>
              <Icon name="arrow-up-right" size={15} />
              {murLien}
            </a>
          </div>
        ) : null}
      </main>

      {acquisition ? (
        /* La clôture est une carte **dans la colonne**, alignée sur le contenu.
           J'avais gardé une seconde variante — l'aplat de clôture de la landing, pleine
           largeur — pour les pages qui composent leurs propres bandes. Aucune n'en
           compose plus depuis que l'invitation est passée en carte : elle serait partie
           en implémentation sans avoir jamais été vue. Une seule clôture, donc.
           Une bande sombre pleine largeur pèserait de toute façon plus lourd que la page
           qu'elle clôt, et son texte, aligné sur la gouttière, démarrerait cent
           cinquante pixels à gauche du contenu qu'elle suit. */
        <div style={{
            width: "100%", maxWidth: largeur, margin: "0 auto", boxSizing: "border-box",
            padding: "0 var(--page-gutter) clamp(34px,5vw,52px)"
          }}>
            <div style={{
              background: "var(--surface-panel)", border: "1px solid var(--border-hairline)",
              borderRadius: "var(--radius-2xl)", padding: "clamp(20px,4vw,26px)",
              display: "flex", gap: 18, alignItems: "center", flexWrap: "wrap"
            }}>
              <div style={{ flex: "1 1 240px", minWidth: 0 }}>
                <div style={{
                  fontFamily: "var(--font-display)",
                  fontVariationSettings: "var(--font-display-settings)",
                  fontWeight: 500, fontSize: "clamp(20px,2.2vw,24px)", lineHeight: 1.15,
                  letterSpacing: "-.022em", textWrap: "balance"
                }}>{t.acqTitre}</div>
                <p style={{
                  margin: "8px 0 0", fontSize: 14.5, lineHeight: 1.5,
                  color: "var(--text-secondary)", textWrap: "pretty"
                }}>{t.acqTexte}</p>
              </div>
              {/* Le CTA mène à la landing : c'est là que vivent la capture d'e-mail
                  avant lancement et les badges de magasins après.
                  Violet et non abricot : sur une surface claire c'est le violet qui agit,
                  et l'abricot ne sert qu'aux moments heureux — l'employer ici en ferait
                  un décor. Rayon 10 px, celui du bouton web : ce lien est peint à la main
                  parce que `Button` ne prend pas de `href`, mais il doit rendre
                  exactement le même bouton que « Commencer », deux cents pixels plus
                  haut dans l'en-tête. */}
              <a href={t.acqUrl || "index.html"} style={{
                display: "inline-block", flex: "none",
                background: "var(--action)", color: "#FFFFFF",
                padding: "14px 24px", borderRadius: "var(--radius-sm)",
                fontFamily: "var(--font-body)", fontWeight: 700, fontSize: 16,
                textDecoration: "none"
              }}>{t.acqAction}</a>
            </div>
        </div>
      ) : null}

      <SiteFooter t={t} nuit={nuit} base={base} onPage={onLegal} />

      {!consenti ? (
        <div style={{
          position: "sticky", bottom: 0, background: "var(--surface-card)",
          borderTop: "1px solid var(--border-object)", padding: "14px var(--page-gutter)"
        }}>
          <div style={{
            maxWidth: "var(--page-max)", margin: "0 auto", display: "flex",
            gap: 14, alignItems: "center", flexWrap: "wrap"
          }}>
            <p style={{
              flex: "1 1 240px", margin: 0, fontSize: 13.5,
              color: "var(--text-secondary)", textWrap: "pretty"
            }}>{t.consentTexte}</p>
            <div style={{ display: "flex", gap: 8 }}>
              <Button variant="outline" onClick={() => setConsenti(true)}>{t.consentRefus}</Button>
              <Button variant="outline" onClick={() => setConsenti(true)}>{t.consentAccord}</Button>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}
