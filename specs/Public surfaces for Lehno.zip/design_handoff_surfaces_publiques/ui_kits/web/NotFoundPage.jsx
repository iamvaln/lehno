import React from "react";
import { Button } from "../../components/core/Button.jsx";

/** 404 — la page dit ce qui s'est passé et propose la suite. Pas d'excuse,
 *  pas d'illustration, pas de « Oups ». */
export function NotFoundPage({ t, onPage }) {
  const p = t.notFound;
  return (
    <div style={{
      display: "grid", gap: 22, justifyItems: "start",
      paddingTop: "clamp(10px,3vw,32px)"
    }}>
      <div style={{
        fontFamily: "var(--font-display)", fontVariationSettings: "var(--font-display-settings)",
        fontWeight: 400, fontSize: "clamp(56px,9vw,92px)", lineHeight: 1,
        letterSpacing: "-.03em", color: "var(--text-accent)"
      }}>404</div>
      <h1 style={{
        margin: 0, fontFamily: "var(--font-display)",
        fontVariationSettings: "var(--font-display-settings)",
        fontWeight: 400, fontSize: "clamp(28px,3.6vw,40px)", lineHeight: 1.1,
        letterSpacing: "-.025em", textWrap: "balance"
      }}>{p.titre}</h1>
      <p style={{
        margin: 0, fontSize: 17, lineHeight: 1.6, color: "var(--text-secondary)",
        maxWidth: "52ch", textWrap: "pretty"
      }}>{p.texte}</p>
      <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 4 }}>
        <Button onClick={() => onPage("landing")}>{p.retour}</Button>
        <Button variant="outline" onClick={() => onPage("faq")}>{p.faq}</Button>
      </div>
    </div>
  );
}
