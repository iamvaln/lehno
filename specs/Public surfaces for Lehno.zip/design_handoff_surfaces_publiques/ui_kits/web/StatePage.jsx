import React from "react";

/** Pages d'état — silhouette « avis court ».
 *
 *  L'objectif de la page est de **ne pas laisser le visiteur dans le vide** : dire
 *  ce qui s'est passé, dire que ce n'est pas sa faute, et rendre la suite évidente.
 *  Elle est donc brève et n'a rien à décorer : pas d'icône dans un carré arrondi
 *  (le cliché que la charte évite partout ailleurs), pas d'illustration, pas
 *  d'« Oups ». Le titre porte l'information, une ligne l'explique, et le pied de
 *  page — le vrai, celui de la landing — offre la sortie.
 *
 *  **Ce gabarit ne sert pas aux pages introuvables.** Un lien révoqué ou une
 *  fenêtre de vœux fermée sont des **liens valides** dont l'état a changé : la page
 *  existe, elle explique. Une adresse qui ne résout pas — y compris le Mur d'un
 *  pseudo non publié, qu'on ne distingue jamais d'un pseudo inexistant (§9.3 :
 *  404, jamais 403) — c'est la page 404 du site, `NotFoundPage`. Deux écrans pour
 *  la même chose, c'est un écran de trop.
 *
 *  `cas` : `lienRevoque` · `horsFenetre`. */
export function StatePage({ t, cas = "lienRevoque" }) {
  const p = t.etats[cas];
  return (
    <div style={{ paddingTop: "clamp(8px,3vw,28px)" }}>
      <h1 style={{
        margin: 0, fontFamily: "var(--font-display)",
        fontVariationSettings: "var(--font-display-settings)",
        fontWeight: 400, fontSize: "clamp(28px,4vw,40px)", lineHeight: 1.08,
        letterSpacing: "-.028em", textWrap: "balance", maxWidth: "22ch"
      }}>{p.titre}</h1>
      <p style={{
        margin: "16px 0 0", fontSize: 17.5, lineHeight: 1.6,
        color: "var(--text-secondary)", maxWidth: "50ch", textWrap: "pretty"
      }}>{p.texte}</p>
      {p.precision ? (
        <p style={{
          margin: "26px 0 0", paddingTop: 16,
          borderTop: "1px solid var(--border-hairline)",
          fontSize: 14, color: "var(--text-mention)", maxWidth: "50ch", textWrap: "pretty"
        }}>{p.precision}</p>
      ) : null}
    </div>
  );
}
