import React from "react";
import { BrandMark } from "../../components/brand/BrandMark.jsx";
import { Wordmark } from "../../components/brand/Wordmark.jsx";
import { Button } from "../../components/core/Button.jsx";
import { Icon } from "../../components/core/Icon.jsx";

export function SiteHeader({ t, nuit, onTheme, langue, onLangue, base = "../../", ancres = "" }) {
  const [ouvert, setOuvert] = React.useState(false);
  // `ancres` prefixe les liens de navigation : vide sur la landing, "index.html"
  // sur une page secondaire, où les sections pointées vivent ailleurs.
  const liens = [
    [ancres + "#comment", t.navComment], [ancres + "#contenu", t.navContenu],
    [ancres + "#mur", t.navMur], [ancres + "#prix", t.navPrix]
  ];
  return (
    <header style={{
      position: "sticky", top: 0, zIndex: 20, background: "var(--surface-page)",
      borderBottom: "1px solid var(--border-hairline)"
    }}>
      <div style={{
        maxWidth: "var(--page-max)", margin: "0 auto",
        padding: "14px var(--page-gutter)", display: "flex", alignItems: "center", gap: 14
      }}>
        <BrandMark base={base} size={30} />
        <Wordmark base={base} variant={nuit ? "blanc" : "couleur"} height={21} />

        <nav className="site-nav" style={{ marginLeft: "auto", display: "flex", gap: 24, alignItems: "center" }}>
          {liens.map(([h, l]) => (
            <a key={h} href={h} style={{
              color: "var(--text-secondary)", textDecoration: "none",
              fontSize: 15, fontFamily: "var(--font-body)"
            }}>{l}</a>
          ))}
        </nav>

        <div style={{ marginLeft: "auto", display: "flex", gap: 8, alignItems: "center" }} className="site-actions">
          <button type="button" onClick={onLangue} className="site-ctrl lehno-focusable"
            aria-label={langue === "fr" ? "Switch to English" : "Passer en français"}
            style={{
              minWidth: 40, minHeight: 34, border: "1px solid var(--border-object)",
              borderRadius: "var(--radius-xs)", background: "none", cursor: "pointer",
              fontFamily: "var(--font-body)", fontSize: 12.5, fontWeight: 700,
              letterSpacing: ".04em", color: "var(--text-secondary)"
            }}>
            {langue === "fr" ? "EN" : "FR"}
          </button>
          <button type="button" onClick={onTheme} className="site-ctrl lehno-focusable"
            aria-label={nuit ? t.themeClair : t.themeSombre}
            style={{
              width: 40, height: 34, display: "grid", placeItems: "center",
              border: "1px solid var(--border-object)", borderRadius: "var(--radius-xs)",
              background: "none", cursor: "pointer", color: "var(--text-secondary)"
            }}>
            <Icon name={nuit ? "sun" : "moon"} size={17} />
          </button>
          <Button className="site-cta" onClick={() => {}}>{t.commencer}</Button>
          <button type="button" className="site-burger lehno-focusable" onClick={() => setOuvert((o) => !o)}
            aria-expanded={ouvert} aria-label={t.menu}
            style={{
              display: "none", width: 40, height: 34, placeItems: "center",
              border: "1px solid var(--border-object)", borderRadius: "var(--radius-xs)",
              background: "none", cursor: "pointer", color: "var(--text-secondary)"
            }}>
            <Icon name={ouvert ? "x" : "menu"} size={18} />
          </button>
        </div>
      </div>

      {ouvert ? (
        <nav className="site-drawer" style={{
          borderTop: "1px solid var(--border-hairline)", padding: "6px var(--page-gutter) 14px"
        }}>
          {liens.map(([h, l]) => (
            <a key={h} href={h} onClick={() => setOuvert(false)} style={{
              display: "block", padding: "13px 0", minHeight: "var(--touch-min)",
              boxSizing: "border-box", color: "var(--text-body)", textDecoration: "none",
              fontSize: 16, borderBottom: "1px solid var(--border-hairline)"
            }}>{l}</a>
          ))}
          <div className="site-drawer-cta" style={{ display: "none", paddingTop: 14 }}>
            <Button full onClick={() => {}}>{t.commencer}</Button>
          </div>
        </nav>
      ) : null}
    </header>
  );
}
