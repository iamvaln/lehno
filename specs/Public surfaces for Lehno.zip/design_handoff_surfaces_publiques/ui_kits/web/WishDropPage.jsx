import React from "react";
import { Button } from "../../components/core/Button.jsx";
import { Banner } from "../../components/feedback/Banner.jsx";

/** Dépôt de vœux — silhouette « billet ».
 *
 *  L'objectif est qu'on écrive un mot en trente secondes, debout, sur son
 *  téléphone. La page se comporte donc comme une carte qu'on écrit : **le champ
 *  de message est la page**, grand, posé sur la surface de carte, avec la
 *  signature en pied du même bloc. Pas de grand titre héroïque au-dessus, pas de
 *  chapeau gris de trois lignes : une ligne de contexte, et on écrit.
 *
 *  Le décompte est ramené à cette ligne de contexte : il dit pourquoi la page est
 *  ouverte aujourd'hui, il n'est pas la vedette. */
export function WishDropPage({ t }) {
  const p = t.voeux;
  const [envoye, setEnvoye] = React.useState(false);
  const [message, setMessage] = React.useState("");
  const [signature, setSignature] = React.useState("");

  if (envoye) {
    return (
      <>
        <div style={{ marginBottom: 20 }}>
          <Banner intent="success">{p.confirmeTitre}</Banner>
        </div>
        <p style={{ margin: 0, fontSize: 17, lineHeight: 1.6, textWrap: "pretty" }}>{p.confirmeTexte}</p>
      </>
    );
  }

  return (
    <form onSubmit={(e) => { e.preventDefault(); setEnvoye(true); }}>
      <div style={{
        display: "flex", alignItems: "baseline", gap: 10, flexWrap: "wrap",
        marginBottom: 10
      }}>
        <span style={{
          fontFamily: "var(--font-display)",
          fontVariationSettings: "var(--font-display-settings)",
          fontWeight: 500, fontSize: 21, letterSpacing: "-.02em",
          color: "var(--text-accent)"
        }}>{p.decompte}</span>
        <span style={{ fontSize: 15.5, color: "var(--text-secondary)" }}>{p.contexte}</span>
      </div>

      <h1 style={{
        margin: "0 0 20px", fontFamily: "var(--font-display)",
        fontVariationSettings: "var(--font-display-settings)",
        fontWeight: 400, fontSize: "clamp(26px,3.4vw,34px)", lineHeight: 1.1,
        letterSpacing: "-.025em", textWrap: "balance"
      }}>{p.titre}</h1>

      <div style={{
        background: "var(--surface-card)", border: "1px solid var(--border-object)",
        borderRadius: "var(--radius-2xl)", padding: "6px 6px 0", overflow: "hidden"
      }}>
        <textarea value={message} onChange={(e) => setMessage(e.target.value)}
          placeholder={p.placeholderMessage} rows={9} className="lehno-focusable"
          aria-label={p.labelMessage}
          style={{
            display: "block", width: "100%", boxSizing: "border-box", border: "none",
            background: "transparent", resize: "vertical",
            fontFamily: "var(--font-body)", fontSize: 17.5, lineHeight: 1.6,
            color: "var(--text-body)", padding: "16px 16px 8px", outlineOffset: 2
          }} />
        <div style={{
          display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap",
          borderTop: "1px solid var(--border-hairline)", margin: "0 -6px",
          padding: "10px 22px 12px"
        }}>
          <label htmlFor="voeu-signature" style={{
            fontSize: 14, color: "var(--text-mention)"
          }}>{p.labelSignature}</label>
          <input id="voeu-signature" value={signature} onChange={(e) => setSignature(e.target.value)}
            placeholder={p.placeholderSignature} className="lehno-focusable"
            style={{
              all: "unset", flex: "1 1 160px", minWidth: 0,
              fontFamily: "var(--font-body)", fontSize: 16, color: "var(--text-body)",
              padding: "6px 0"
            }} />
        </div>
      </div>

      <div style={{
        display: "flex", gap: 14, alignItems: "center", flexWrap: "wrap", marginTop: 18
      }}>
        <Button type="submit" disabled={!message.trim()}>{p.envoyer}</Button>
        <span style={{
          fontSize: 13, color: "var(--text-mention)", flex: "1 1 200px", textWrap: "pretty"
        }}>{p.mention}</span>
      </div>
    </form>
  );
}
