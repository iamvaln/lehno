import React from "react";
import { BrandMark } from "../../components/brand/BrandMark.jsx";
import { Wordmark } from "../../components/brand/Wordmark.jsx";

export function SiteFooter({ t, nuit, base = "../../", liens, onPage }) {
  return (
    <footer style={{ background: "var(--surface-page)" }}>
      <div style={{
        maxWidth: "var(--page-max)", margin: "0 auto",
        padding: "40px var(--page-gutter) 64px", display: "flex",
        gap: 28, alignItems: "flex-start", flexWrap: "wrap"
      }}>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <BrandMark base={base} size={26} />
            <Wordmark base={base} variant={nuit ? "blanc" : "couleur"} height={18} />
          </div>
          <div className="lehno-parole" style={{
            fontSize: 15, color: "var(--text-secondary)", marginTop: 6
          }}>{t.signature}</div>
        </div>
        <nav style={{
          marginLeft: "auto", display: "flex", gap: 22, flexWrap: "wrap",
          fontSize: 14, color: "var(--text-secondary)"
        }}>
          {(liens || [
            { id: "cgu", label: t.cgu }, { id: "confidentialite", label: t.confidentialite },
            { id: "faq", label: t.piedFaq }, { id: "contact", label: t.contact }
          ]).map((l) => (
            <a key={l.id} href={l.href || "#"} className="site-footlink"
              onClick={onPage ? (e) => { e.preventDefault(); onPage(l.id); } : undefined}
              style={{ color: "var(--text-secondary)", textDecoration: "none" }}>{l.label}</a>
          ))}
        </nav>
      </div>
    </footer>
  );
}
