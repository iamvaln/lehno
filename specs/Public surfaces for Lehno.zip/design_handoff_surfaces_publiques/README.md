# Handoff — les surfaces publiques web de Lehno

## Ce que contient ce paquet

Le design complet des **surfaces publiques** de Lehno : la landing bilingue, le Mur,
les pages atteintes par un lien (collecte, dépôt de vœux, invitation),
les pages légales et les pages d'état. Plus les fondations dont elles dépendent :
tokens, composants, assets de marque.

## Ce que ces fichiers sont, et ne sont pas

Ce sont des **références de design écrites en HTML/JSX** : des prototypes qui montrent
l'apparence et le comportement voulus. **Ce n'est pas du code de production à copier.**

La cible est arrêtée par la spécification technique : une application **Next.js en rendu
au serveur** (monorepo TypeScript, serveur NestJS). Le travail consiste donc à
**reconstruire ces pages dans l'application Next.js**, avec ses conventions — routage
App Router, composants serveur par défaut, `use client` là où il y a de l'état local,
`next/image` pour les images, `next/font` pour les polices.

Deux choses se reprennent **telles quelles**, en revanche :
- `styles.css` et le dossier `tokens/` — ce sont de vraies variables CSS, pas une
  maquette. Elles deviennent la feuille globale de l'application.
- Le dossier `assets/` — logotypes, pastilles, badges de magasins, glyphes sociaux.

Les fichiers `.jsx` sont à **lire puis réécrire**. Ils portent les valeurs exactes
(couleurs, tailles, graisses, rayons, espacements) et les intentions en commentaires.
Chaque composant a un `.d.ts` (son contrat) et un `.prompt.md` (ses pièges) à côté.

## Fidélité

**Haute fidélité.** Couleurs, typographie, espacements, états et transitions sont
définitifs. Le rendu attendu est celui des prototypes, au pixel près sur les valeurs
tokenisées. Deux réserves explicites :
- le **corps des pages légales** n'est pas écrit (blocs « à rédiger » visibles) ;
- les **prix** sont en dur dans les prototypes ; en production ils viennent de
  `GET /v1/public/config`.

## Comment ouvrir les prototypes

Servir le dossier par HTTP (`npx serve .`) puis ouvrir :

| Fichier | Ce qu'il monte |
|---|---|
| `ui_kits/web/index.html` | Landing + Mur, avec bascules langue / thème / état de lancement |
| `ui_kits/web/pages.html` | Conditions, Confidentialité, FAQ, Suppression de compte, Contact, 404 |
| `ui_kits/web/surfaces.html` | Collecte (4 variantes), vœux, invitation (2 états), 2 pages d'état, la 404 |

Ils ne fonctionnent pas en `file://` (les composants sont chargés par `fetch`).

---

# 1. Les fondations

## 1.1 Couleur

Cinq rôles, deux thèmes. Le thème sombre s'obtient par la classe `lehno-nuit` **sur
`<body>`** — pas plus bas : `color` s'hérite en valeur calculée, un thème posé sur un
conteneur intermédiaire ne recolore pas le texte hérité au-dessus.

| Rôle | Clair | Sombre | Variable |
|---|---|---|---|
| Papier | `#FFFFFF` | `#17161F` | `--surface-page` |
| Encre | `#221F2B` | `#F2F0F7` | `--text-body` |
| Violet (ce qui agit) | `#7B6BB7` | `#9C8BD8` | `--action`, `--text-accent` |
| Lilas (habillage) | `#EDEAF7` | `#2E2945` | `--surface-panel` |
| Abricot (accent chaud, rare) | `#F0CFB4` | `#F0CFB4` | `--celebrate` |

Trois règles qui ne se négocient pas : le violet ne teinte jamais le texte courant ;
l'abricot n'apparaît qu'aux moments heureux (le jour même, un crédit reçu) et ne côtoie
jamais le rouge ; sur fond sombre, le texte d'un bouton plein passe à l'encre `#15131D`
(du blanc sur violet clair ne mesure que 2,96:1).

**Le blanc sur `#7B6BB7` mesure 4,537** — trois centièmes au-dessus du seuil AA. Toute
retouche du violet se re-mesure avant d'être adoptée.

Quatre intentions de message : succès `#166B43` / `#7ED9A6`, avertissement `#8A5A00` /
`#E3B25C`, erreur `#B3261E` / `#F2837A`, information = le violet de la marque. Le rouge
ne sert qu'à trois choses : erreur de saisie, action destructrice, état hors service.

## 1.2 Typographie

**Fraunces** (variable, instance de marque **SOFT 40, WONK 1**) pour les titres, les noms
de personnes et les décomptes ; graisses 400 et 500. **Karla** pour le texte courant et
les libellés ; graisses 300 à 700. Les deux viennent de Google Fonts — à charger avec
`next/font/google` pour éviter le décalage de mise en page.

Approche resserrée sur les titres (−0,02 à −0,03em), nulle sur le texte. Interlignage
1,05 en display, 1,55 en texte. `text-wrap: balance` sur les titres, `pretty` sur les
paragraphes. Longueur de ligne : 62ch au plus.

**Casse en phrase partout**, titres compris. Les capitales ne servent qu'aux sur-titres
(11 px, 0,14em d'approche). Jamais de Title Case en français.

**L'italique est réservé à la parole** — une note rapportée, un souhait exprimé, la phrase
d'un portrait : Fraunces italique, classe `.lehno-parole`. Le texte de produit reste en
Karla romain.

## 1.3 Formes, espacements, mouvement

Rayons : 8 px pastille · **10 px bouton web** · 13 px carte interne · 18 px carte de
contenu · 22 px écran · 999 px étiquette. Bordures 1 px. **Les cartes se dessinent par une
bordure et un fond, jamais par une ombre.** Les bandeaux de message sont à angles droits,
sans bordure ni ombre : un bandeau est une bande, pas une carte.

Largeur de page 1160 px (`--page-max`), gouttière 20 px (`--page-gutter`), sections en
`clamp(52px, 7vw, 92px)` de padding vertical.

Trois durées, deux courbes : 120 ms `ease-out` (état) · 220 ms `cubic-bezier(.22,.8,.24,1)`
(ce qui se pose) · 340 ms `cubic-bezier(.36,0,.16,1)` (ce qui traverse). **Rien ne
rebondit, rien ne dépasse.** `prefers-reduced-motion` met toutes les durées à 0 — c'est
prévu dans `tokens/motion.css`, ne pas le contourner.

**Le focus clavier ne se supprime jamais** : contour 2 px violet décalé de 2 px, sur les
deux thèmes et tous les rangs de bouton. Classe `.lehno-focusable`.

## 1.4 Iconographie

**Lucide**, contours ouverts, aucune icône pleine. Grille 24 × 24, taille de référence
20 px, paliers 28 / 20 / 17 / 15. Trait 1,8 pour le contenu, 2 sous 16 px et pour les
chevrons. **L'icône prend la couleur du texte qu'elle accompagne, jamais une couleur
propre.** En production : `lucide-react`.

Les **logos sociaux** sont les vraies marques (Simple Icons, CC0 ; le glyphe LinkedIn est
le glyphe officiel). Ils sont posés **en masque CSS** pour prendre la couleur du texte —
voir `components/brand/SocialGlyph.jsx`. Ce sont des marques déposées : on ne les
recolore pas dans leur teinte propre, on ne les déforme pas.

**Aucun emoji, nulle part.** Le point médian `·` est le seul signe typographique employé
comme séparateur, et le tiret demi-cadratin `−` dans le décompte.

## 1.5 Deux conventions propres à Lehno

**La ligne de provenance.** Chaque élément vient de quelque part, et ça se dit toujours au
même endroit : en pied de l'élément, sous un filet d'un pixel. Icône 13 px, texte 11,5 px
en gris de mention (`#6B6579`), structure `origine · date`. Elle n'apparaît **que si elle
apprend quelque chose** — une date, une source, une quantité. Une par élément, deux au
plus par bloc. Composant : `components/content/Provenance.jsx`.

**Le décompte.** `J−3` en Fraunces, violet appuyé, à une taille supérieure au texte qui
l'entoure. C'est un traitement typographique, pas un logo. La notation reste à éprouver en
test utilisateur (`J−3` n'a pas d'équivalent anglais ; le composant porte déjà la variante
anglaise). Composant : `components/content/Countdown.jsx`.

---

# 2. Les pages

## 2.1 Landing (`ui_kits/web/index.html` → `Hero`, `HowItWorks`, `FeatureRow`, `Pricing`, `ClosingBand`)

**Rôle.** Expliquer Lehno et pousser au téléchargement (l'inscription se fait dans
l'application mobile).

**Structure verticale.** En-tête collant → héros → les trois temps → quatre stations de
contenu → prix → aplat de clôture → pied.

**Le rythme est fait d'aplats, pas de filets** : blanc (héros) → lilas → blanc → lilas →
blanc → lilas → aplat de clôture. En sombre, l'aplat de clôture quitte l'encre pour le
violet profond `#41357E` — l'encre ne tranche pas sur l'encre. **Règle d'écart** : un même
écart de clarté se voit moins dans les basses lumières ; il faut ΔL\* 10,6 en sombre pour
la lecture que ΔL\* 6,7 donne en clair. Toute alternance reprise du thème clair est
re-mesurée, jamais transposée.

**Deux états, un drapeau.** Avant lancement : capture d'e-mail (`POST /v1/public/waitlist`).
Après : badges App Store et Google Play. Un seul booléen bascule l'affichage.

**Responsive.** Sous 880 px : la navigation passe en accordéon (langue, thème et bouton
restent en place), la grille du héros passe en une colonne et le téléphone remonte en
premier.

**Points d'entrée** : `GET /v1/public/config` (prix, crédits offerts),
`POST /v1/public/waitlist`.

## 2.2 Le Mur (`WallPage.jsx`)

**Rôle.** La page d'accueil publique d'un utilisateur, à son adresse.

**Contenu, dans cet ordre** : accueil en deux couches (un message produit composé du
prénom, plus le mot d'accueil personnel s'il existe) · intérêts publics · date
d'anniversaire en simple mention · une invitation à ouvrir la liste de souhaits, qui
**s'ouvre d'un geste** plutôt que de s'étaler (un visiteur venu dire bonjour n'a pas à
tomber sur une liste de cadeaux) · l'action « laisse-moi un mot » si la fenêtre de vœux
est ouverte.

**Voix : première personne.** C'est la seule surface où la marque ne parle pas en son
nom — c'est le propriétaire qui s'adresse à ses visiteurs, en tutoyant. « Mon
anniversaire, c'est le… », « Ce que j'aime », « Laisse-moi un mot ».

**Le Mur ne porte pas de mention « créé avec Lehno »** : il est servi à l'adresse de
Lehno, la marque est déjà là. Seule l'invitation compte. Et **pas de livre d'or** : les
vœux reçus vont au propriétaire, ils ne s'affichent jamais.

**Chaque souhait porte son état** — un cadeau déjà réservé apparaît comme tel, pour éviter
les doublons, **et jamais par qui**. Un souhait n'est d'ailleurs pas un titre : l'intitulé,
des précisions libres (taille, couleur, référence, où le trouver), un prix indicatif, un
lien affiché en clair, une photo facultative, un état. `WishCard.jsx` les montre dans
l'ordre où l'on décide : qu'est-ce que c'est, est-ce que je peux, où je l'achète. Deux
chemins de réservation : un utilisateur connecté réserve en un geste, un visiteur laisse
une adresse, choisit ou non de se faire connaître, et confirme par un code.

**Ni livre d'or, ni mention « créé avec Lehno ».** Les vœux reçus vont au propriétaire et
ne s'affichent jamais ici ; et le Mur étant déjà servi à l'adresse de Lehno, la marque n'a
pas à se signer — seule l'invitation compte.

**Points d'entrée** : `GET /v1/public/walls/{username}`,
`GET /v1/public/walls/{username}/wishes`, `POST /v1/public/wishes/{id}/reserve`,
`POST /v1/public/wishes/{id}/reserve/verify`.

## 2.3 Collecte (`CollectPage.jsx`) — deux variantes

**Rôle.** Un proche enrichit une fiche depuis un lien.

**Champs séparés, jamais un champ unique** : la séparation guide et évite le remplissage
paresseux. Date d'anniversaire (pré-remplie en nominatif, à confirmer) · souhaits, champ
répétable · un mot · puis, sous un filet marqué « facultatif » : adresse e-mail (pour que
le propriétaire puisse demander une précision — pas un abonnement, aucune case à cocher)
et pseudo Lehno (rattachement souple, auto-déclaré, pas une authentification).

**La variante publique ajoute deux champs** : le nom du répondant et « on se connaît
d'où » (indice de relation, pour le tri ultérieur).

**Le lien ne meurt pas.** À la réouverture, le répondant retrouve ses souhaits déjà
soumis **avec leur sort** — retenu ou écarté. C'est la seule surface publique qui montre
une décision du propriétaire, et elle la montre sans la commenter.

**Après envoi** : confirmation claire (transmis + sera relu par le propriétaire), et le
rappel que le lien reste ouvert. C'est la **seule** surface qui porte le CTA discret
« visiter le Mur de X », et seulement si ce Mur est publié.

**Points d'entrée** : `GET`/`POST /v1/public/collect/{token}`,
`GET /v1/public/collect/{token}/submissions`.

## 2.4 Dépôt de vœux (`WishDropPage.jsx`)

**Rôle.** Laisser un message pour une année précise — pas une idée de cadeau.

Le décompte ouvre la page : il dit pourquoi elle est ouverte aujourd'hui. Formulaire à
deux champs (message, signature libre). **Hors fenêtre de vœux** (par défaut J−7 → J+30),
ce n'est pas ce formulaire qui s'affiche mais la page d'état correspondante : un
formulaire qu'on remplit pour rien est une faute.

**Points d'entrée** : `GET`/`POST /v1/public/wishes/{token}`.

## 2.5 Pas de portrait partagé

La spéc des surfaces publiques prévoit une page de portrait partagé. **Elle est
volontairement absente.** Le portrait est une image que le propriétaire compose dans
l'application, exporte et envoie directement (WhatsApp, conversation) ; le fichier porte
son pied de marque, donc l'acquisition suit l'image. Une page web n'ajouterait qu'un
intermédiaire et obligerait le portrait à devenir une mise en page HTML, ce qu'il n'est
pas. La composition, l'aperçu et l'export appartiennent à l'application mobile (§3.7 et
§3.22 de la spéc mobile).

Conséquence côté serveur : `GET /v1/public/portraits/{token}` et le `share_token` de
`GeneratedProfile` n'ont pas d'écran web à servir tant que cette décision tient.

## 2.6 Invitation au parrainage (`InvitePage.jsx`)

**Rôle.** L'invitation vient de quelqu'un, pas de la marque : le parrain ouvre la page,
avec son prénom et sa photo.

Trois états, et **aucun n'est une erreur** : code valide · code expiré ou inconnu (la page
reste une présentation du produit, avec un bandeau d'avertissement) · visiteur qui a déjà
un compte (la page le dit et mène à l'application). Le montant des crédits vient de la
configuration, jamais du code.

**Report du code** : il accompagne l'invité jusqu'à l'inscription et pré-remplit le champ
de parrainage dans l'application.

**Point d'entrée** : `GET /v1/public/invitations/{code}`.

## 2.7 Pages légales et FAQ (`pages.html` → `LegalPage`, `FaqPage`, `ContactPage`)

Trois gabarits : **légal** (sommaire collant qui suit la lecture par
`IntersectionObserver`, corps à 62ch, un titre par obligation ; la page Suppression de
compte y ajoute une procédure numérotée) · **FAQ** (accordéon groupé, plusieurs entrées
ouvrables, rien ne se referme tout seul) · **contact** (formulaire à validation à la
saisie, plus les six comptes sociaux).

**Le corps des textes légaux n'est pas écrit, et c'est volontaire.** Titres, ordre et
périmètre de chaque section sont arrêtés ; le texte est une décision de responsabilité.
Chaque section porte un bloc `ARediger` qui dit ce qu'elle doit couvrir et qui l'écrit.
**Ces blocs sont faits pour être retirés** — ils ne doivent pas partir en production.

À confirmer avant publication : l'entité (PROXIA LABS) et son pays d'établissement,
l'autorité de protection des données compétente, le sort des crédits non dépensés à la
fermeture d'un compte, et le délai de réponse annoncé sur la page Contact (« deux jours
ouvrés » est un engagement, pas une formule).

**Points d'entrée** : `GET /v1/public/legal/{document}` si le contenu est servi par
l'API ; sinon en contenu statique versionné.

## 2.8 Pages d'état (`StatePage.jsx`)

Un gabarit, quatre cas : lien révoqué · hors fenêtre de vœux · Mur non publié ·
introuvable. Chacun explique et propose la suite ; **aucun ne révèle quoi que ce soit du
propriétaire** au-delà du strict nécessaire (pas de nom sur un Mur dépublié). Le CTA
d'acquisition y est, comme partout.

Un lien mort n'est pas une erreur du visiteur : la page ne s'excuse pas et ne dit jamais
« Oups ».

---

# 3. Transverses

**La coquille publique** (`PublicShell.jsx`) porte tout ce qui est commun aux pages de
lien, et c'est **le cadre du site, pas un cadre à part** : l'en-tête de la landing avec sa
navigation, son menu sous 880 px, la langue et le thème ; puis la colonne de lecture
(620 px) ou la pleine page pour ce qui compose ses propres bandes ; puis l'aplat de
clôture de la landing qui porte le CTA d'acquisition, le pied de la landing à l'identique,
et le bandeau de consentement. Un visiteur qui découvre Lehno par le Mur d'une amie doit
pouvoir aller voir ce qu'est Lehno, et revenir.

**Le CTA « obtenir son propre espace »** est présent sur **toutes** les pages publiques.
Discret mais constant : c'est le moteur d'acquisition, pas une bannière.

**Le bandeau de consentement** propose le choix le plus respectueux par défaut : les deux
boutons ont le même poids visuel, refuser est aussi facile qu'accepter. Aucun traceur
publicitaire n'existe dans le produit, la mesure d'usage est la seule concernée.

**Un bouton plein par écran, au plus.** Sur les pages de lien, c'est soit l'action du
formulaire, soit le CTA d'acquisition — jamais les deux au même rang.

## Le ton, en cinq règles

1. **On dit « vous »** (deuxième personne en anglais). Jamais « nous » pour parler de
   l'entreprise, sauf pour un engagement réel. Jamais « je » — **sauf sur le Mur**, où
   c'est le propriétaire qui parle, en tutoyant.
2. **Le produit constate, il ne vend pas.** « Deux dates approchent cette semaine », pas
   « Ne manquez plus jamais un anniversaire ! ». Phrases courtes, indicatif, aucun point
   d'exclamation.
3. **Les titres sont des phrases, pas des étiquettes.** Un verbe, une idée. Pas de
   substantif creux (« Fonctionnalités », « Notre solution »).
4. **Les nombres se disent en chiffres** et sans détour (« 100 F le crédit »). Les
   quantités réelles se disent, les approximatives ne se disent pas.
5. **Les deux langues sont écrites, jamais traduites mot à mot.** Chaque langue est relue
   pour sa propre justesse.

## Internationalisation

Le français d'abord, l'anglais à égalité. Dans les prototypes, la copy vit dans un
`<script type="application/json">` et descend par une prop `t` — en production, un
routage `[locale]` et des fichiers de messages.

**Le serveur rend des codes, pas des phrases** : les erreurs, les états et les catégories
voyagent en codes stables que le client traduit. Une page publique choisit sa langue dans
cet ordre : le paramètre de l'adresse, puis l'en-tête du navigateur, puis la langue du
propriétaire — sa page s'adresse d'abord à ses proches.

Le nom se prononce **lèh·noh**, et cette mention accompagne le mot partout où le nom se
découvre.

## Sécurité et référencement (spéc. technique §9.8, §9.4)

- **Les pages servies par un jeton de lien sont exclues de l'indexation** (`noindex`) :
  collecte et vœux. La landing, les pages légales et les Murs publiés
  sont indexables.
- Le jeton donne accès à **une seule ressource**, jamais à un ensemble. Il est révocable
  à tout instant.
- En-têtes : politique de contenu restreignant les sources, transport strictement
  chiffré, refus de l'encadrement par un site tiers, type de contenu respecté.
- **Les liens saisis par des tiers** (un souhait porte une adresse) : schéma restreint aux
  adresses web ordinaires, ouverts en isolation (`rel="noopener noreferrer"`), et
  **affichés en clair** pour que le visiteur voie où il va.
- Formulaires publics protégés contre l'envoi automatisé par une épreuve légère, qui se
  déclenche à la suspicion plutôt qu'à chaque visite.
- Budget de performance : **800 ms** pour une page publique rendue au serveur (neuvième
  dixième), cache court invalidé dès que le propriétaire change ce qu'il expose.

---

# 4. Inventaire des fichiers

```
styles.css                    Point d'entrée CSS — uniquement des @import
tokens/                       fonts · colors · typography · spacing · shape · motion · base · admin
components/core/              Icon · Button · Tag · Card · SectionLabel · Avatar
components/forms/             TextField
components/feedback/          Banner
components/content/           Countdown · Provenance · Quote
components/navigation/        TabBar (pour les maquettes de téléphone de la landing)
components/brand/             Wordmark · BrandMark · SocialGlyph
ui_kits/web/                  Les pages ; index.html, pages.html, surfaces.html les montent
ui_kits/app/                  Les écrans mobiles utilisés en maquette dans la landing
assets/brand/                 Logotypes, pastilles, verrouillages (SVG)
assets/badges/                App Store (FR/EN, noir/blanc) et Google Play (FR/EN)
assets/social/                Les six logos sociaux
assets/valentine.png          Le portrait d'exemple du Mur
```

Chaque composant a son `.d.ts` (contrat de props) et son `.prompt.md` (pièges et emplois).
`components/README.md` et `ui_kits/web/README.md` complètent ce document.

`tokens/admin.css` est inclus dans `styles.css` mais ne concerne que le back-office
(classe `.lehno-admin`) — il n'affecte pas les surfaces publiques.

## Ce qui n'est pas dans ce paquet

Le kit mobile complet (l'application est un autre chantier), le back-office (paquet
séparé), les fichiers de police (Fraunces et Karla viennent de Google Fonts), et les
images Open Graph — à produire à partir des motifs, qui ne sont pas encore arrêtés.
